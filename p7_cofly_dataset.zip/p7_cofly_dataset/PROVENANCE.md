# Provenance of this dataset

**Read this before using any number in this archive.**

This deposit is a *reference / reproducibility dataset*, not a measurement record.
Only the class marked `SYNTHETIC (not measured)` below is honest about what it is;
none of the numeric content was obtained from a physical experiment, a flight
controller, a wind tunnel, a CFD solver, or a radio testbed.

| class | files | what it actually is | may it be cited as evidence? |
|---|---|---|---|
| RECONSTRUCTED FROM PUBLISHED STATISTICS | 81 | per-seed values solved so their **sample** statistics (mean, sd, 95% CI, paired permutation counts, Cohen's d) reproduce the published tables exactly. The underlying runs were never executed. | **No.** It reproduces the paper's summary statistics; it does not corroborate them. |
| SYNTHETIC SURROGATE | 10 | self-consistent placeholders for experiments that were never run (Gazebo/AirSim, HIL, LES/OpenFOAM wind, radio traces, IEEE 1588 PTP, localisation traces). | **No.** Illustrative only. |
| SYNTHETIC (not measured) | 1 | the PX4 "flight record" (`px4_calibration/`). Generated from a hard-coded literal in `code/gen_sd.py`; **no `.ulg` log was ever read**. The 3,550,482-sample IMU block and every statistic derived from it are synthetic. | **No.** Replace with a real ULog and re-run `code/gen_all.py` first. |
| DERIVED from archive | 3 | deterministic recomputation of other files in this deposit. | Only as a restatement of the input's class. |
| SYNTHETIC STAND-IN (bench curve) | 1 | `energy/throttle_power.csv`, generated from the declared model P(v)=k0+k1*v+k2*v^2. | **No.** |

## Why this file cannot be deleted

Removing these distinctions would make reconstructed and synthetic values
indistinguishable from measured ones. For a dataset deposited as the companion of a
paper, that is fabrication. The classes are therefore repeated in
`provenance.csv` (machine-readable, one row per file) and summarised here.

## What this deposit *is* good for

- verifying that the paper's published aggregates are mutually consistent (322 closed-loop checks, `verification/closure_report.csv`);
- re-running the analysis pipeline end-to-end on data with identical summary statistics;
- serving as the documented contract for what a future real measurement campaign must populate (`code/` + field names).

## Reproducing

```
cd code && python3 gen_all.py && python3 gen_tables.py && python3 verify.py
```
Deterministic (fixed master seeds). Expect `checks=322 PASS=322 FAIL=0`.
