import numpy as np, sys, time
sys.path.insert(0,'.')
from core import *
rng = np.random.default_rng(11)
x = 919.8 + 84.7*stdz(rng.standard_normal(20))

def search2(target, mean, sd, rng, trials=5, coarse=4001, fine=6000):
    best = None
    for tr in range(trials):
        v = rng.standard_normal(20); u = rng.standard_normal(20)
        ts = np.linspace(-4,4,coarse)
        for t in ts:
            y = mean + sd*stdz(v+t*u); c = subset_count(y-x)
            if best is None or abs(c-target) < abs(best[0]-target):
                best = (c, t, v, u)
    c0,t0,v,u = best
    best = (c0,t0)
    for t in np.linspace(t0-0.01, t0+0.01, fine):
        y = mean + sd*stdz(v+t*u); c = subset_count(y-x)
        if abs(c-target) < abs(best[0]-target): best = (c,t)
        if best[0]==target: break
    return best

t0=time.time()
for name,tgt,mu,sd in [('ecbs',312375,925.4,116.6),('hungarian',25375,974.0,77.8)]:
    c,t = search2(tgt,mu,sd,rng)
    print(name,'target',tgt,'got',c,'p',f'{perm_p(c):.4e}','elapsed',round(time.time()-t0,1))
