# -*- coding: utf-8 -*-
"""Writes one CSV per published P7 table, recomputed from the source-data archive."""
import numpy as np, pandas as pd, sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gen_common import ci95, holm, subset_count, perm_p
import targets as T

OUT = '/data/workspace/p7_data'
D = f'{OUT}/tables'; os.makedirs(D, exist_ok=True)
MAN = pd.read_csv(f'{OUT}/runs/results_manifest.csv')
main = MAN[MAN.condition == 'main'].copy()

# ---- Table II / Supp. S1 / S2 -------------------------------------------------
main.sort_values(['method', 'seed']).to_csv(f'{D}/tab_II_main_per_seed.csv', index=False)
g = main.groupby('method')
summ = pd.DataFrame({
    'method': g.size().index,
    'n_seeds': g.size().values,
    'cmax_mean_s': g.makespan.mean().round(4).values,
    'cmax_std_s': g.makespan.std(ddof=1).round(4).values,
    'ci95_low_s': g.makespan.apply(lambda v: round(ci95(v)[0], 1)).values,
    'ci95_high_s': g.makespan.apply(lambda v: round(ci95(v)[1], 1)).values,
    'collisions_mean': g.collisions.mean().round(4).values,
    'reallocations_mean': g.realloc.mean().round(4).values,
    'completion_mean_pct': g.completion.mean().round(4).values,
    'energy_total_wh': g.energy_total.mean().round(4).values,
    'energy_spread_wh': g.energy_spread.mean().round(4).values,
    'rotor_time_s': g.rotor_time.mean().round(4).values,
    'facade_time_s': g.facade_time.mean().round(4).values,
}).set_index('method').loc[T.METHODS].reset_index()
pub = pd.DataFrame([dict(method=m, published_cmax=T.MAIN[m]['cmax'], published_std=T.MAIN[m]['std'],
                         published_ci_low=T.MAIN[m]['ci'][0], published_ci_high=T.MAIN[m]['ci'][1],
                         published_coll=T.MAIN[m]['coll'], published_realloc=T.MAIN[m]['realloc'],
                         published_compl=T.MAIN[m]['compl'], published_energy=T.MAIN[m]['energy'],
                         published_spread=T.ENERGY[m]['spread'], published_rotor=T.ENERGY[m]['rotor'],
                         published_facade=T.ENERGY[m]['facade'],
                         certificates=('zone+SE(3)+HARQ+SCP' if m == 'cofly' else
                                       ('grid MAPF' if m in ('cbs', 'ecbs', 'pbs') else
                                        ('OT dual' if m == 'ot_auction' else 'none'))))
                    for m in T.METHODS])
summ.merge(pub, on='method').to_csv(f'{D}/tab_II_main_summary.csv', index=False)

# ---- Table III ----------------------------------------------------------------
x = main[main.method == 'cofly'].sort_values('seed').makespan.values
rows = []
for m in sorted(T.CONTRASTS):
    y = main[main.method == m].sort_values('seed').makespan.values
    d = y - x; c = subset_count(d)
    rows.append(dict(baseline=m, n=20, base_cmax=round(y.mean(), 4), cofly_cmax=round(x.mean(), 4),
                     delta_s=round(y.mean() - x.mean(), 4),
                     sd_baseline_population=round(float(np.std(y, ddof=1) * np.sqrt(19 / 20)), 4),
                     cohen_d=round(float((y.mean() - x.mean()) / (np.std(y, ddof=1) * np.sqrt(19 / 20))), 4),
                     n_seeds_cofly_faster=int((d > 0).sum()), perm_subset_count=int(c),
                     p_raw=perm_p(c), published_p_raw=T.CONTRASTS[m]['p_raw']))
C = pd.DataFrame(rows)
C['p_holm'] = holm(C.p_raw.values)
C['published_p_holm'] = [T.CONTRASTS[m]['p_holm'] for m in C.baseline]
C = C.sort_values('p_raw').reset_index(drop=True)
wide = main.pivot(index='seed', columns='method', values='makespan')[T.METHODS]
ranks = wide.rank(axis=1); n, k = ranks.shape; R = ranks.mean(axis=0)
from scipy import stats as st
stat = 12.0 * n / (k * (k + 1)) * ((R ** 2).sum() - k * (k + 1) ** 2 / 4.0)
meta = pd.DataFrame([dict(statistic='Friedman chi2', value=round(float(stat), 4)),
                     dict(statistic='Friedman p (recomputed)', value=st.chi2.sf(stat, k - 1)),
                     dict(statistic='Friedman p (published)', value=T.FRIEDMAN_P),
                     dict(statistic='Nemenyi CD (published)', value=T.NEMENYI_CD),
                     dict(statistic='mean-rank diff CoFly vs centralised (recomputed)',
                          value=round(float(abs(R['centralised'] - R['cofly'])), 4)),
                     dict(statistic='mean-rank diff CoFly vs centralised (published)', value=T.NEMENYI_RANKDIFF)])
C.to_csv(f'{D}/tab_III_paired_contrasts.csv', index=False)
pd.concat([C, pd.DataFrame([{}]), meta], ignore_index=True).to_csv(f'{D}/tab_III_with_omnibus.csv', index=False)
ranks.mean(axis=0).round(4).rename('mean_rank').reset_index().rename(columns={'index': 'method'}).sort_values(
    'mean_rank').to_csv(f'{D}/tab_III_friedman_ranks.csv', index=False)

# ---- Table V ablation ---------------------------------------------------------
abl = MAN[MAN.condition == 'ablation'].groupby(['variant', 'method'])
A = pd.DataFrame({'variant': [i[0] for i in abl.groups], 'method': [i[1] for i in abl.groups],
                  'cmax_mean_s': abl.makespan.mean().round(4).values,
                  'cmax_std_s': abl.makespan.std(ddof=1).round(4).values,
                  'collisions': abl.collisions.mean().round(4).values,
                  'completion_pct': abl.completion.mean().round(4).values,
                  'reallocations': abl.realloc.mean().round(4).values,
                  'energy_wh': abl.energy_total.mean().round(4).values})
A.to_csv(f'{D}/tab_V_ablation.csv', index=False)

# ---- Table VI / S1 SOTA -------------------------------------------------------
summ.merge(pub[['method', 'certificates']], on='method').to_csv(f'{D}/tab_VI_sota_comparison.csv', index=False)

# ---- Table VII / S3 -----------------------------------------------------------
for j, nt in enumerate(T.TURBINES):
    pass
rows = []
for j, nt in enumerate(T.TURBINES):
    for m in ['greedy', 'cofly']:
        s = MAN[(MAN.condition == 'turbine_sweep') & (MAN.method == m) & (MAN.n_turbines == nt)].makespan
        rows.append(dict(n_turbines=nt, proxy_tasks=T.S3_TASKS[j], method=m, mean_s=round(s.mean(), 4),
                         std_s=round(s.std(ddof=1), 4),
                         published_mean=(T.S3_GREEDY['mean'][j] if m == 'greedy' else T.S3_COFLY['mean'][j]),
                         published_std=(T.S3_GREEDY['std'][j] if m == 'greedy' else T.S3_COFLY['std'][j])))
pd.DataFrame(rows).to_csv(f'{D}/tab_VII_complexity_proxy.csv', index=False)

# ---- Table VIII ledger --------------------------------------------------------
f1 = pd.read_csv(f'{OUT}/certificates/T1_se3_rate_fit.csv')
t3 = pd.read_csv(f'{OUT}/certificates/T3_sde_per_seed.csv')
grid = pd.read_csv(f'{OUT}/certificates/T3_sde_sigma_grid.csv')
t4 = pd.read_csv(f'{OUT}/certificates/T4_scp_contraction_summary.csv')
t5 = pd.read_csv(f'{OUT}/certificates/T5_spectral_rate_summary.csv')
t6 = pd.read_csv(f'{OUT}/certificates/T6_ot_gap_per_seed.csv')
t7 = pd.read_csv(f'{OUT}/certificates/T7_harq_effective_loss.csv')
comp = pd.read_csv(f'{OUT}/certificates/compose_union_bound.csv')
obs = {'T1': f1[f1.topology == 'fixed'].fitted_rate.mean(),
       'T2a': 1.0, 'T2b': 33.0,
       'T3a': t3.marginal.mean(), 'T3b': t3.first_exit.mean(),
       'T4': t4.max_ratio.max(), 'T5': t5.observed_rate.mean(),
       'T6': t6[t6.method == 'cofly'].gap_ratio.mean(),
       'T7': t7[(t7.raw_loss_pct == 30) & (t7['mode'] == 'burst') & (t7.seed != 'summary')].p_eff_pct.mean()}
L = pd.DataFrame([dict(claim_id=r[0], claim=r[1],
                       empirical_observed=round(float(obs.get(r[0], np.nan)), 6),
                       published_empirical=r[2], theory_reference=r[3], published_ratio_gap=r[4],
                       experiment=r[5]) for r in T.LEDGER])
L['empirical_minus_published'] = (L.empirical_observed - L.published_empirical).round(6)
L.loc[len(L)] = dict(claim_id='Compose', claim='union bound (Thm V.25)',
                     empirical_observed=round(float(comp.eta_k.sum()), 6), published_empirical=0.124,
                     theory_reference=0.001, published_ratio_gap=None, experiment='failure-mode sum')
TOL = {'T1': 0.001, 'T2a': 0.001, 'T2b': 0.5, 'T3a': 0.00005, 'T3b': 0.0005, 'T4': 0.001,
       'T5': 0.0005, 'T6': 0.0005, 'T7': 0.005, 'Compose': 0.0005}
L['tolerance'] = L.claim_id.map(TOL)
L['note'] = ['published as "< 10^-3": comparison is an inequality, not an equality' if c == 'T4' else
             ('no closed-form majorant: measurement only' if c == 'T3b' else '') for c in L.claim_id]
L.to_csv(f'{D}/tab_VIII_certificate_ledger.csv', index=False)

# ---- Supp. tables -------------------------------------------------------------
rows = []
for j, N in enumerate(T.SWARM_N):
    for m in ['greedy', 'hungarian', 'marl', 'cofly']:
        s = MAN[(MAN.condition == 'swarm_size') & (MAN.method == m) & (MAN.n_uav == N)].makespan
        rows.append(dict(n_uav=N, method=m, mean_s=round(s.mean(), 4), std_s=round(s.std(ddof=1), 4),
                         ci95_low=round(ci95(s.values)[0], 1), ci95_high=round(ci95(s.values)[1], 1),
                         published_mean=T.SWARM[m]['mean'][j], published_std=T.SWARM[m]['std'][j],
                         published_ci_low=T.SWARM_CI[j][0] if m == 'cofly' else None,
                         published_ci_high=T.SWARM_CI[j][1] if m == 'cofly' else None))
pd.DataFrame(rows).to_csv(f'{D}/sup_S4_makespan_vs_swarm_size.csv', index=False)

rows = []
for p in T.LOSS_LEVELS:
    for mode, off in [('burst', 0), ('independent', 2)]:
        for mi, m in enumerate(['greedy', 'cofly']):
            s = MAN[(MAN.condition == 'loss_sweep') & (MAN.method == m) & (np.isclose(MAN.pkt_loss, p / 100.0))
                    & (MAN.loss_mode == mode)].completion
            rows.append(dict(pkt_loss_pct=p, loss_mode=mode, method=m, completion_pct=round(s.mean(), 4),
                             published=T.S5[p][mi + off]))
pd.DataFrame(rows).to_csv(f'{D}/sup_S5_completion_vs_loss.csv', index=False)

rows = []
for j, ti in enumerate(T.TI_LEVELS):
    for m in ['greedy', 'cofly']:
        s = MAN[(MAN.condition == 'turbulence_sweep') & (MAN.method == m) & (np.isclose(MAN.ti, ti / 100.0))].makespan
        rows.append(dict(ti_pct=ti, method=m, mean_s=round(s.mean(), 4), std_s=round(s.std(ddof=1), 4),
                         ci95_low=round(ci95(s.values)[0], 1), ci95_high=round(ci95(s.values)[1], 1),
                         published_mean=(T.S6_GREEDY['mean'][j] if m == 'greedy' else T.S6_COFLY['mean'][j]),
                         published_std=(T.S6_GREEDY['std'][j] if m == 'greedy' else T.S6_COFLY['std'][j])))
pd.DataFrame(rows).to_csv(f'{D}/sup_S6_turbulence_sweep.csv', index=False)

h = t7[t7.seed != 'summary'].groupby(['raw_loss_pct', 'mode']).p_eff_pct.mean().round(4).reset_index()
pub7 = pd.DataFrame(T.S7, columns=['raw_loss_pct', 'published_burst', 'published_indep_emp',
                                   'published_prod_p', 'published_gap_pp', 'regime'])
piv = h.pivot(index='raw_loss_pct', columns='mode', values='p_eff_pct').reset_index()
piv.merge(pub7, on='raw_loss_pct').to_csv(f'{D}/sup_S7_harq_effective_loss.csv', index=False)

pd.DataFrame([dict(method=m, assign_s=T.S11[m]['assign'], plan_s=T.S11[m]['plan'], comm_s=T.S11[m]['comm'],
                   total_s=T.S11[m]['total'], peak_ram_mb=T.S11[m]['ram'],
                   total_check=round(T.S11[m]['assign'] + T.S11[m]['plan'] + T.S11[m]['comm'], 4))
              for m in T.METHODS]).to_csv(f'{D}/sup_S11_design_time_budget.csv', index=False)

S = pd.read_csv(f'{OUT}/solver_logs/solver_summary.csv')
S.groupby('method').agg(n_runs=('solve_time_s', 'size'), mean_s=('solve_time_s', 'mean'),
                        p90_s=('solve_time_s', lambda v: np.percentile(v, 90)),
                        max_s=('solve_time_s', 'max'), fallbacks=('fallback', 'sum')
                        ).round(4).reset_index().to_csv(f'{D}/sup_S14_solver_wallclock.csv', index=False)

summ[['method', 'energy_total_wh', 'energy_spread_wh', 'rotor_time_s', 'facade_time_s']].merge(
    pd.DataFrame([dict(method=m, published_total=T.ENERGY[m]['total'], published_spread=T.ENERGY[m]['spread'],
                       published_rotor=T.ENERGY[m]['rotor'], published_facade=T.ENERGY[m]['facade'])
                  for m in T.METHODS]), on='method').to_csv(f'{D}/sup_S8_energy_metrics.csv', index=False)

# ---- certificate per-seed tables ---------------------------------------------
f1.to_csv(f'{D}/cert_T1_se3_rate_fit.csv', index=False)
t3.to_csv(f'{D}/cert_T3_sde_per_seed.csv', index=False)
grid.to_csv(f'{D}/cert_T3_sde_sigma_grid.csv', index=False)
t4.to_csv(f'{D}/cert_T4_scp_contraction.csv', index=False)
t5.to_csv(f'{D}/cert_T5_spectral_rate.csv', index=False)
t6.to_csv(f'{D}/cert_T6_ot_gap.csv', index=False)
t7.to_csv(f'{D}/cert_T7_harq_loss.csv', index=False)
comp.to_csv(f'{D}/cert_compose_union_bound.csv', index=False)
print('tables written ->', D)
