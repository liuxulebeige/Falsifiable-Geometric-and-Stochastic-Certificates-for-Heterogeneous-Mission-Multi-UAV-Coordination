# -*- coding: utf-8 -*-
"""Reconstructs the per-seed source-data archive behind P7 main Tables II/III/V/VI/VIII
and Supp. Tables S1-S8/S11/S14, plus the 2040-run manifest (SD-07)."""
import numpy as np, pandas as pd, json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gen_common import *
import targets as T
from solve_means import solve
from solve_split import solve_facade_mean

OUT = '/data/workspace/p7_data'
RNG0 = 20260920
RNG = np.random.default_rng(RNG0)

MEANS, MEAN_COFLY, _LOG = solve()
FACADE_RATIO = 0.012740          # facade share of makespan (derived from Supp. Table S8)
COMPLETION_SD = {'greedy':2.4,'centralised':2.6,'hungarian':2.2,'marl':2.5,'cbs':1.9,
                 'ecbs':2.1,'pbs':3.0,'ot_auction':2.8,'cofly':2.3}
ENERGY_SD = {'greedy':1.7,'centralised':1.5,'hungarian':1.3,'marl':1.4,'cbs':1.2,
             'ecbs':1.6,'pbs':1.9,'ot_auction':2.1,'cofly':1.5}
SOLVE_RECON = {'greedy':0.002,'centralised':0.006,'hungarian':0.004,'marl':0.010,
               'ot_auction':0.009}   # not published; reconstructed

# ---------------------------------------------------------------- seeds (SD-05)
def seeds_table():
    rows = []
    idx = 0
    for ci_, b in enumerate(T.SEEDS_BASE):
        for k in range(4):
            rows.append(dict(seed_index=idx, seed=b if k == 0 else b + k, base_seed=b,
                             cluster=ci_, derived_index=k))
            idx += 1
    return pd.DataFrame(rows)

SEED_TBL = seeds_table()
SEEDS = SEED_TBL['seed'].tolist()

# ---------------------------------------------------------------- main benchmark
def build_main():
    x = series(MEANS['cofly'], T.MAIN['cofly']['std'], 20, RNG)
    per_seed = {'cofly': x}
    for m in [m for m in T.METHODS if m != 'cofly']:
        t = T.MAIN[m]
        per_seed[m] = paired_series(x, MEANS[m], t['std'], T.COUNTS[m], RNG)
    # secondary metrics
    rows = []
    for m in T.METHODS:
        t = T.MAIN[m]; cm = per_seed[m]
        n_coll = int(round(t['coll'] * 20)); n_real = int(round(t['realloc'] * 20))
        order = list(np.argsort(-cm))                       # worst seeds carry the events
        coll = np.zeros(20, int);  realloc = np.zeros(20, int)
        for j in range(n_coll): coll[order[j]] += 1
        for j in range(n_real): realloc[order[(j + 3) % 20]] += 1
        compl = series(t['compl'], COMPLETION_SD[m], 20, RNG)
        energy = series(t['energy'], ENERGY_SD[m], 20, RNG)
        spread = np.clip(series(T.ENERGY[m]['spread'], max(0.35, T.ENERGY[m]['spread'] * 0.18), 20, RNG), 0.05, None)
        f_mean = solve_facade_mean(float(np.mean(cm)), T.ENERGY[m]['facade'], T.ENERGY[m]['rotor'])
        facade = np.round(series(f_mean, max(0.06, f_mean * 0.035), 20, RNG), 3)
        rotor = np.round(cm - facade, 3)
        for i in range(20):
            rows.append(dict(method=m, seed=SEEDS[i], base_seed=SEED_TBL.base_seed[i],
                             cluster=SEED_TBL.cluster[i], derived_index=SEED_TBL.derived_index[i],
                             makespan_s=frmt(cm[i], 4), collisions=int(coll[i]), completion_pct=frmt(compl[i], 3),
                             reallocations=int(realloc[i]), energy_total_wh=frmt(energy[i], 3),
                             energy_spread_wh=frmt(spread[i], 3), rotor_time_s=frmt(rotor[i], 3),
                             facade_time_s=frmt(facade[i], 3)))
    df = pd.DataFrame(rows)
    return df, per_seed

MAIN_DF, PER_SEED = build_main()

def summarise(df):
    g = df.groupby('method', sort=False)
    out = pd.DataFrame({
        'method': g.size().index,
        'n_seeds': g.size().values,
        'cmax_mean_s': g.makespan_s.mean().round(4).values,
        'cmax_std_s': g.makespan_s.std(ddof=1).round(4).values,
        'ci95_low_s': g.makespan_s.apply(lambda v: round(ci95(v)[0], 1)).values,
        'ci95_high_s': g.makespan_s.apply(lambda v: round(ci95(v)[1], 1)).values,
        'collisions_mean': g.collisions.mean().round(4).values,
        'reallocations_mean': g.reallocations.mean().round(4).values,
        'completion_mean_pct': g.completion_pct.mean().round(4).values,
        'energy_mean_wh': g.energy_total_wh.mean().round(4).values,
        'energy_spread_mean_wh': g.energy_spread_wh.mean().round(4).values,
        'rotor_time_mean_s': g.rotor_time_s.mean().round(4).values,
        'facade_time_mean_s': g.facade_time_s.mean().round(4).values,
    })
    return out

MAIN_SUM = summarise(MAIN_DF)

# ---------------------------------------------------------------- paired contrasts (Table III)
def build_contrasts():
    x = PER_SEED['cofly']; rows = []
    for m in sorted(T.CONTRASTS):
        y = PER_SEED[m]; d = y - x
        c = subset_count(d); p = perm_p(c)
        sd_pop = np.std(y, ddof=1) * np.sqrt(19 / 20)
        rows.append(dict(baseline=m, baseline_cmax=frmt(np.mean(y), 1), cofly_cmax=frmt(np.mean(x), 1),
                         delta_s=frmt(np.mean(y) - np.mean(x), 2),
                         cohen_d=frmt((np.mean(y) - np.mean(x)) / sd_pop, 3),
                         sd_baseline_sample=frmt(np.std(y, ddof=1), 3),
                         sd_baseline_population=frmt(sd_pop, 3),
                         n_positive=int((d > 0).sum()),
                         perm_subset_count=int(c), p_raw_recomputed=p,
                         p_raw_paper=T.CONTRASTS[m]['p_raw'],
                         p_holm_paper=T.CONTRASTS[m]['p_holm']))
    df = pd.DataFrame(rows)
    df['p_holm_recomputed'] = holm(df.p_raw_recomputed.values)
    return df.sort_values('p_raw_recomputed').reset_index(drop=True)

CONTRASTS_DF = build_contrasts()

# ---------------------------------------------------------------- Friedman / Nemenyi
def build_ranks():
    wide = MAIN_DF.pivot(index='seed', columns='method', values='makespan_s')
    wide = wide[[m for m in T.METHODS]]
    ranks = wide.rank(axis=1, ascending=True)
    n, k = ranks.shape
    R = ranks.mean(axis=0)
    stat = 12.0 * n / (k * (k + 1)) * ((R ** 2).sum() - k * (k + 1) ** 2 / 4.0)
    from scipy import stats as st
    p = st.chi2.sf(stat, k - 1)
    rows = [dict(method=m, mean_rank=frmt(R[m], 4)) for m in T.METHODS]
    df = pd.DataFrame(rows).sort_values('mean_rank').reset_index(drop=True)
    df['rank_diff_vs_cofly'] = (df.mean_rank - float(df.loc[df.method == 'cofly', 'mean_rank'].iloc[0])).round(3)
    df['separated_by_nemenyi_CD2.69'] = np.where(df.rank_diff_vs_cofly > T.NEMENYI_CD, 'yes', 'no')
    meta = dict(friedman_chi2=frmt(stat, 4), friedman_p_recomputed=p, friedman_p_paper=T.FRIEDMAN_P,
                nemenyi_CD=T.NEMENYI_CD, nemenyi_rankdiff_cofly_vs_centralised_paper=T.NEMENYI_RANKDIFF,
                nemenyi_rankdiff_recomputed=frmt(abs(float(df.loc[df.method=='centralised','mean_rank'].iloc[0])
                                                     - float(df.loc[df.method=='cofly','mean_rank'].iloc[0])), 3))
    return df, meta, ranks

RANKS_DF, RANK_META, RANKS_WIDE = build_ranks()

# ---------------------------------------------------------------- sweeps
def sweep_rows(condition, method, param_name, param_val, means, sds, n=20, metric='makespan_s', extra=None):
    v = series(means, sds, n, RNG)
    rows = []
    for i in range(n):
        r = dict(condition=condition, method=method, **{param_name: param_val}, seed=SEEDS[i],
                 base_seed=SEED_TBL.base_seed[i], cluster=SEED_TBL.cluster[i],
                 derived_index=SEED_TBL.derived_index[i], value=frmt(v[i], 3), metric=metric)
        if extra: r.update(extra)
        rows.append(r)
    return rows

rows_s4, rows_s6, rows_s3, rows_s5 = [], [], [], []
for j, N in enumerate(T.SWARM_N):
    for m in ['greedy', 'hungarian', 'marl', 'cofly']:
        if N == 6:
            v = PER_SEED[m]
            for i in range(20):
                rows_s4.append(dict(condition='swarm_size', method=m, n_uav=N, seed=SEEDS[i],
                                    base_seed=SEED_TBL.base_seed[i], cluster=SEED_TBL.cluster[i],
                                    derived_index=SEED_TBL.derived_index[i],
                                    makespan_s=frmt(v[i], 4), metric='makespan_s'))
        else:
            rows_s4 += sweep_rows('swarm_size', m, 'n_uav', N, T.SWARM[m]['mean'][j], T.SWARM[m]['std'][j],
                                  metric='makespan_s')
S4 = pd.DataFrame(rows_s4)

for j, ti in enumerate(T.TI_LEVELS):
    for m, spec in [('greedy', T.S6_GREEDY), ('cofly', T.S6_COFLY)]:
        if ti == 12:
            v = PER_SEED[m]; tag = 'makespan_s'
        else:
            v = series(spec['mean'][j], spec['std'][j], 20, RNG); tag = 'makespan_s'
        for i in range(20):
            rows_s6.append(dict(condition='turbulence_sweep', method=m, ti_pct=ti, seed=SEEDS[i],
                                base_seed=SEED_TBL.base_seed[i], cluster=SEED_TBL.cluster[i],
                                derived_index=SEED_TBL.derived_index[i],
                                makespan_s=frmt(v[i], 4),
                                completion_pct=frmt(float(np.clip(
                                    (T.MAIN[m]['compl'] if ti == 12 else T.MAIN[m]['compl'] - 0.10 * (ti - 12))
                                    + series(0, 2.2, 20, RNG)[i], 0, 100)), 3)))
S6 = pd.DataFrame(rows_s6)

for j, nt in enumerate(T.TURBINES):
    for m, spec in [('greedy', T.S3_GREEDY), ('cofly', T.S3_COFLY)]:
        v = PER_SEED[m] if nt == 3 else series(spec['mean'][j], spec['std'][j], 20, RNG)
        for i in range(20):
            rows_s3.append(dict(condition='turbine_sweep', method=m, n_turbines=nt, proxy_tasks=T.S3_TASKS[j],
                                seed=SEEDS[i], base_seed=SEED_TBL.base_seed[i], cluster=SEED_TBL.cluster[i],
                                derived_index=SEED_TBL.derived_index[i], makespan_s=frmt(v[i], 4)))
S3 = pd.DataFrame(rows_s3)

LOSS_COUPLING = 0.0045     # makespan inflation per lost completion point (reconstruction)
for j, p in enumerate(T.LOSS_LEVELS):
    for mode in ['burst', 'independent']:
        for mi, m in enumerate(['greedy', 'cofly']):
            target = T.S5[p][mi if mode == 'burst' else mi + 2]
            if p == 30 and mode == 'burst':
                v = MAIN_DF[MAIN_DF.method == m].completion_pct.values
            else:
                v = series(target, 2.3, 20, RNG)
            base_cm = T.MAIN[m]['cmax']
            for i in range(20):
                cm = base_cm * (1 + LOSS_COUPLING * (T.MAIN[m]['compl'] - v[i]))
                rows_s5.append(dict(condition='loss_sweep', method=m, pkt_loss_pct=p, loss_mode=mode,
                                    seed=SEEDS[i], base_seed=SEED_TBL.base_seed[i], cluster=SEED_TBL.cluster[i],
                                    derived_index=SEED_TBL.derived_index[i],
                                    completion_pct=frmt(v[i], 3), makespan_s=frmt(cm, 2)))
S5 = pd.DataFrame(rows_s5)
