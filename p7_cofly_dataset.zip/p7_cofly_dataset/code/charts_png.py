# -*- coding: utf-8 -*-
import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
for f in ['DejaVu Sans']:
    pass
plt.rcParams['font.sans-serif'] = ['DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False
OUT='/data/workspace/p7_data'; CH='/data/workspace/charts'
MAN=pd.read_csv(f'{OUT}/runs/results_manifest.csv')
main=MAN[MAN.condition=='main']
BLUE='#1F3864'; ORANGE='#C55A11'; GREY='#8C8C8C'; GREEN='#2E7D32'

# 1 makespan with CI
order=['greedy','pbs','ot_auction','centralised','cbs','ecbs','marl','hungarian','cofly']
g=main.groupby('method').makespan.agg(['mean','std','count']).loc[order]
hw=2.09302*g['std']/np.sqrt(g['count'])
fig,ax=plt.subplots(figsize=(9,4.6))
colors=[GREY if m!='cofly' else BLUE for m in order]
bars=ax.bar(range(len(order)), g['mean'], yerr=hw, capsize=4, color=colors, edgecolor='white')
for i,(m,r) in enumerate(zip(order,g.iterrows())):
    ax.text(i, r[1]['mean']+hw[i]+35, f"{r[1]['mean']:.1f}", ha='center', fontsize=9)
ax.set_xticks(range(len(order))); ax.set_xticklabels(order, fontsize=9)
ax.set_ylabel('makespan $C_{max}$ (s)')
ax.set_title('Main benchmark: makespan by method (mean ± 95% CI, n = 20 matched seeds)', fontsize=11, color=BLUE)
ax.set_ylim(0, 2900); ax.spines[['top','right']].set_visible(False)
ax.axhline(main[main.method=='greedy'].makespan.mean(), color=ORANGE, ls='--', lw=1)
ax.annotate('greedy 2503.2 s', xy=(0,2530), xytext=(0.4,2650), color=ORANGE, fontsize=9)
ax.annotate('CoFly 919.8 s (−63.3% vs greedy)', xy=(8,1000), xytext=(5.6,1500), color=BLUE, fontsize=9,
            arrowprops=dict(arrowstyle='->', color=BLUE, lw=1))
fig.tight_layout(); fig.savefig(f'{CH}/fig1_makespan_ci.png', dpi=170); plt.close(fig)

# 2 swarm size
fig,ax=plt.subplots(figsize=(9,4.6))
for m,c,ls in [('greedy',GREY,'-'),('hungarian',ORANGE,'-'),('marl',GREEN,'-'),('cofly',BLUE,'-')]:
    d=MAN[(MAN.condition=='swarm_size')&(MAN.method==m)].groupby('n_uav').makespan.mean()
    ax.plot(d.index, d.values, marker='o', color=c, ls=ls, label=m, lw=1.8)
ax.set_xlabel('number of UAVs'); ax.set_ylabel('makespan (s)')
ax.set_title('Scaling with fleet size (Supp. S4): CoFly wins at N = 4, 6, 10 but is beaten at N = 8', fontsize=11, color=BLUE)
ax.legend(frameon=False, fontsize=9); ax.spines[['top','right']].set_visible(False)
ax.annotate('N = 8: Hungarian 693.5 s / MARL 690.0 s < CoFly 755.1 s',
            xy=(8,720), xytext=(5.4,1900), fontsize=9, color=ORANGE,
            arrowprops=dict(arrowstyle='->', color=ORANGE, lw=1))
fig.tight_layout(); fig.savefig(f'{CH}/fig2_swarm_scaling.png', dpi=170); plt.close(fig)

# 3 T3 sigma grid
g3=pd.read_csv(f'{OUT}/certificates/T3_sde_sigma_grid.csv')
fig,ax=plt.subplots(figsize=(9,4.6))
ax.plot(g3.sigma, g3.mc_marginal_sim, marker='o', color=BLUE, label='Monte Carlo marginal (measured)')
ax.plot(g3.sigma, g3.chernoff_bound, marker='s', color=ORANGE, label='Chernoff bound $\\Phi(-(d_{min}-s_0)/\\sigma_\\infty)$')
ax.set_yscale('log'); ax.set_xlabel('OU intensity $\\sigma$'); ax.set_ylabel('collision probability (log scale)')
ax.set_title('T3: the certified marginal stays under the bound on the whole grid (ratio $\\Gamma$ = 10.3 at $\\sigma$ = 0.5)', fontsize=11, color=BLUE)
ax.legend(frameon=False, fontsize=9); ax.spines[['top','right']].set_visible(False)
ax.annotate('$\\sigma$ = 0.5: measured 0.0075 vs bound 0.0773', xy=(0.5,0.0075), xytext=(0.55,0.0009),
            fontsize=9, color=BLUE, arrowprops=dict(arrowstyle='->', color=BLUE, lw=1))
fig.tight_layout(); fig.savefig(f'{CH}/fig3_t3_sigma_grid.png', dpi=170); plt.close(fig)

# 4 HARQ
t7=pd.read_csv(f'{OUT}/certificates/T7_harq_effective_loss.csv')
h=t7[t7.seed!='summary'].groupby(['raw_loss_pct','mode']).p_eff_pct.mean().unstack()
fig,ax=plt.subplots(figsize=(9,4.6))
ax.plot(h.index, h['burst'], marker='o', color=BLUE, label='burst (Gilbert–Elliott)')
ax.plot(h.index, h['independent'], marker='s', color=ORANGE, label='independent-link product $\\prod p_\\ell$')
ax.set_xlabel('raw per-link loss (%)'); ax.set_ylabel('effective loss after HARQ (%)')
ax.set_title('T7: assuming independent links understates the loss by 0.73 pp at 30% (3.429% vs 2.700%)', fontsize=11, color=BLUE)
ax.legend(frameon=False, fontsize=9); ax.spines[['top','right']].set_visible(False)
ax.annotate('0.729 pp gap', xy=(30,3.05), xytext=(33,7.5), fontsize=9, color=BLUE,
            arrowprops=dict(arrowstyle='->', color=BLUE, lw=1))
fig.tight_layout(); fig.savefig(f'{CH}/fig4_harq_burst.png', dpi=170); plt.close(fig)
print('charts ->', CH)
