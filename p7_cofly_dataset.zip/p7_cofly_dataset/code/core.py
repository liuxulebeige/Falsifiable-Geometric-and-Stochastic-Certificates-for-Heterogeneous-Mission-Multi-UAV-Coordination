import numpy as np

def _subset_sums(v):
    arr = np.zeros(1, dtype=np.float64)
    for x in v:
        arr = np.concatenate((arr, arr + x))
    return arr

def subset_count(d, tol=1e-9):
    """Exact #{B subset of seeds : sum_{i in B} d_i <= 0}, via half-split + searchsorted."""
    d = np.asarray(d, dtype=np.float64)
    n = len(d)
    h = n // 2
    a = np.sort(_subset_sums(d[:h]))
    b = np.sort(_subset_sums(d[h:]))
    # count pairs a+b <= tol
    return int(np.searchsorted(b, tol - a, side='right').sum())

def stdz(w):
    w = np.asarray(w, dtype=float)
    return (w - w.mean()) / w.std(ddof=1)

def rescale(y, mean, sd):
    y = np.asarray(y, dtype=float)
    return mean + sd * (y - y.mean()) / y.std(ddof=1)

def make_y(x, mean, sd, r, rng):
    zx = stdz(x)
    e = rng.standard_normal(len(x))
    w = r * zx + np.sqrt(max(1e-12, 1 - r * r)) * e
    return mean + sd * stdz(w)

def perm_p(count, n=20):
    return 2.0 * count / 2.0 ** n
