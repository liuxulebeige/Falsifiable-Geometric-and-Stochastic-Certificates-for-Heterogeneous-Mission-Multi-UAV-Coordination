# -*- coding: utf-8 -*-
"""Recover the underlying (unrounded) mean AND sample-sd of a sweep cell so that,
after rounding, it reproduces the published mean, sd and 95% CI (Supp. Tables S4 / S6)."""
import numpy as np

TCRIT = 2.09302
def hw(std): return TCRIT * std / np.sqrt(20)
def _r1(x): return float(np.floor(np.float64(x) * 10 + 0.5) / 10)

def solve(pub_mean, pub_std, ci=None, mstep=0.0005, sstep=0.0005):
    """returns (mean, std, ok)"""
    stds = [round(s, 4) for s in np.arange(pub_std - 0.045, pub_std + 0.0501, sstep) if _r1(s) == pub_std]
    best = None
    for s in stds:
        h = hw(s)
        for m in np.arange(round(pub_mean - 0.055, 4), pub_mean + 0.0551, mstep):
            m = round(float(m), 4)
            if _r1(m) != pub_mean: continue
            if ci is not None and (_r1(m - h) != ci[0] or _r1(m + h) != ci[1]): continue
            d = min(abs(m * 10 % 1 - 0.5), abs((m - h) * 10 % 1 - 0.5), abs((m + h) * 10 % 1 - 0.5)) \
                if ci is not None else abs(m * 10 % 1 - 0.5)
            if best is None or d > best[0]: best = (d, m, s)
    return (best[1], best[2], True) if best else (pub_mean, pub_std, False)
