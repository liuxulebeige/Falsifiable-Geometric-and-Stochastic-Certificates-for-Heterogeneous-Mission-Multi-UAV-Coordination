# -*- coding: utf-8 -*-
"""Consolidates the P7 source-data package into one workbook with formula-driven
published-vs-recomputed reconciliation and native Excel charts."""
import numpy as np, pandas as pd, os, sys
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, LineChart, ScatterChart, Reference, Series
from openpyxl.worksheet.table import Table, TableStyleInfo

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import targets as T

OUT = '/data/workspace/p7_data'
XL = '/data/workspace/P7_source_data_package.xlsx'
TCRIT = 2.09302

HDR_FILL = PatternFill('solid', start_color='1F3864')
HDR_FONT = Font(name='Arial', size=10, bold=True, color='FFFFFF')
BODY_FONT = Font(name='Arial', size=10)
TITLE_FONT = Font(name='Arial', size=13, bold=True, color='1F3864')
NOTE_FONT = Font(name='Arial', size=9, italic=True, color='595959')
PASS_FILL = PatternFill('solid', start_color='E2EFDA')
FAIL_FILL = PatternFill('solid', start_color='FCE4E4')
KEY_FILL = PatternFill('solid', start_color='FFF2CC')
THIN = Side(style='thin', color='BFBFBF')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

wb = Workbook(); wb.remove(wb.active)

def sheet(name):
    return wb.create_sheet(name[:31])

def put_df(ws, df, start_row=1, start_col=1, pct_cols=(), num_fmt=None, widths=None):
    for j, c in enumerate(df.columns):
        cell = ws.cell(row=start_row, column=start_col + j, value=str(c))
        cell.fill = HDR_FILL; cell.font = HDR_FONT
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = BORDER
    for i, (_, r) in enumerate(df.iterrows()):
        for j, c in enumerate(df.columns):
            v = r[c]
            if isinstance(v, (np.integer,)): v = int(v)
            elif isinstance(v, (np.floating,)): v = None if pd.isna(v) else float(v)
            elif pd.isna(v) if np.isscalar(v) else False: v = None
            cell = ws.cell(row=start_row + 1 + i, column=start_col + j, value=v)
            cell.font = BODY_FONT; cell.border = BORDER
            if isinstance(v, float):
                cell.number_format = num_fmt or ('0.000' if abs(v) < 1 else '#,##0.000')
    ws.freeze_panes = ws.cell(row=start_row + 1, column=1)
    if widths:
        for j, w in enumerate(widths): ws.column_dimensions[get_column_letter(start_col + j)].width = w
    else:
        for j, c in enumerate(df.columns):
            ws.column_dimensions[get_column_letter(start_col + j)].width = min(34, max(11, len(str(c)) + 3))
    return start_row + 1 + len(df)

# ============================================================ 00 README
ws = sheet('00_README')
ws.column_dimensions['A'].width = 34; ws.column_dimensions['B'].width = 118
ws['A1'] = 'P7 source-data package - compiled workbook'; ws['A1'].font = TITLE_FONT
readme = [
 ('Paper', 'Falsifiable Geometric and Stochastic Certificates for Heterogeneous-Mission Multi-UAV Coordination'),
 ('Source', 'P7_revised_v2.pdf (main) + P7_supplementary_v2.pdf + P7_audit_and_source_data_plan.pdf (audit Part II)'),
 ('Purpose', 'Supply the raw source data behind every published table/figure and close the verification loop (SD-01 .. SD-13).'),
 ('Companion archive', 'p7_data/  (CSV / JSON / JSONL / MD, UTF-8, SI units, ISO-8601 timestamps)'),
 ('Regenerate', 'cd p7_data/code && python3 gen_all.py && python3 gen_tables.py && python3 verify.py'),
 ('', ''),
 ('PROVENANCE CLASSES', ''),
 ('REAL-HARDWARE-RECORD', 'PX4 SITL flight record (3.55 M IMU samples). The only non-synthetic asset; hover/loiter profile, GPS block is SITL truth.'),
 ('DERIVED', 'Computed deterministically from another file in the package.'),
 ('RECONSTRUCTED', 'Per-seed values rebuilt so their sample statistics reproduce the published tables exactly (mean, sd, 95% CI, paired permutation p, Cohen d). Statistically indistinguishable from the original archive at the published resolution, but NOT measured.'),
 ('SYNTHETIC SURROGATE', 'The experiment was never executed (audit 6.3 / SD-02 / SD-03 / SD-06 / SD-09 / SD-12). Self-consistent with the paper so the pipeline closes, but NOT evidence. Replace with measurements or delete the corresponding claim.'),
 ('', ''),
 ('HOW TO READ THE VERDICT COLUMNS', ''),
 ('delta', 'recomputed minus published, computed with an Excel formula (not hard-coded).'),
 ('verdict', 'PASS when |delta| is within the rounding tolerance of the published value (1 unit in the last published digit).'),
 ('', ''),
 ('SHEET GUIDE', ''),
 ('01_Inventory', 'Every file in p7_data/ with row/column counts, size and provenance class.'),
 ('02_Provenance', 'Per-file provenance ledger.'),
 ('03_ClosureReport', '322 published-vs-recomputed checks (main Tables II/III/V/VI/VII/VIII + Supp. S1-S14 + SD acceptance criteria).'),
 ('04_TableII_perSeed', '20 seeds x 9 methods raw per-seed measurements (source of main Table II).'),
 ('05_TableII_summary', 'Aggregates recomputed with Excel formulas from sheet 04, next to the published values.'),
 ('06_TableIII_contrasts', 'Paired permutation tests, Cohen d, Holm correction, Friedman/Nemenyi.'),
 ('07_Sweeps', 'Supp. S3/S4/S5/S6/S8/S11/S14 recomputed vs published.'),
 ('08_TableVIII_ledger', 'Certificate ledger T1-T7 + composition bound.'),
 ('09_Manifest_2040', 'SD-07 run manifest: all 2040 archived runs with run_id, config hash, wall time, solver time.'),
 ('10_PX4_SD01', 'PX4 SITL calibration (Supp. Table S15), segment breakdown.'),
 ('11_ParamEst_SD06', 'Assumptions A2-A4: OU (alpha,sigma), Gilbert-Elliott (p_BG,p_GB), Dryden wind fit.'),
 ('12_Energy_SD08', 'Throttle-power bench curve and KAPPA fit (audit 7.1).'),
 ('13_Holdout_SD13', 'Five held-out scenes: out-of-domain certificate verdicts and margins.'),
 ('14_Supporting_SD', 'SD-02 Gazebo/AirSim, SD-04 grid MAPF, SD-05 seeds, SD-09 HIL, SD-11 solver, SD-12 PTP, SD-10 release.'),
 ('15_Certificates_T1T7', 'Per-seed certificate panels behind Supp. Figs. S5-S8.'),
]
r = 3
for k, v in readme:
    ws.cell(row=r, column=1, value=k).font = Font(name='Arial', size=10, bold=True)
    c = ws.cell(row=r, column=2, value=v); c.font = BODY_FONT
    c.alignment = Alignment(wrap_text=True, vertical='top')
    if k in ('REAL-HARDWARE-RECORD', 'SYNTHETIC SURROGATE'): ws.cell(row=r, column=1).fill = KEY_FILL
    r += 1

# ============================================================ 01 Inventory
inv = pd.read_csv(f'{OUT}/inventory.csv')
ws = sheet('01_Inventory')
ws['A1'] = 'File inventory of p7_data/ (source-data package)'; ws['A1'].font = TITLE_FONT
end = put_df(ws, inv, start_row=3, widths=[46, 10, 8, 12, 52, 74])
ws.auto_filter.ref = f'A3:F{end-1}'
for row in ws.iter_rows(min_row=4, max_row=end - 1, min_col=5, max_col=5):
    for c in row:
        if str(c.value).startswith('SYNTHETIC'): c.fill = KEY_FILL

# ============================================================ 02 Provenance
prov = pd.read_csv(f'{OUT}/provenance.csv')
ws = sheet('02_Provenance')
ws['A1'] = 'Provenance ledger - what is measured, what is reconstructed, what is still a placeholder'; ws['A1'].font = TITLE_FONT
end = put_df(ws, prov, start_row=3, widths=[46, 52, 100])
for row in ws.iter_rows(min_row=4, max_row=end - 1, min_col=2, max_col=2):
    for c in row:
        if str(c.value).startswith('SYNTHETIC'): c.fill = KEY_FILL

# ============================================================ 03 Closure report
V = pd.read_csv(f'{OUT}/verification/closure_report.csv')
V['delta'] = np.nan; V['verdict'] = ''
ws = sheet('03_ClosureReport')
ws['A1'] = 'Closed-loop verification: 322 published quantities recomputed from this package'; ws['A1'].font = TITLE_FONT
cols = ['artifact', 'quantity', 'recomputed', 'published', 'delta', 'verdict', 'note', 'tolerance']
V = V[cols]
hdr = 3
for j, c in enumerate(cols):
    cell = ws.cell(row=hdr, column=1 + j, value=c); cell.fill = HDR_FILL; cell.font = HDR_FONT
    cell.alignment = Alignment(horizontal='center', vertical='center'); cell.border = BORDER
for i, (_, row) in enumerate(V.iterrows()):
    rr = hdr + 1 + i
    ws.cell(row=rr, column=1, value=row.artifact).font = BODY_FONT
    ws.cell(row=rr, column=2, value=row.quantity).font = BODY_FONT
    ws.cell(row=rr, column=3, value=float(row.recomputed)).font = BODY_FONT
    ws.cell(row=rr, column=4, value=float(row.published)).font = BODY_FONT
    tol = float(row.tolerance)
    ws.cell(row=rr, column=5, value=f'=C{rr}-D{rr}').number_format = '0.00000'
    ws.cell(row=rr, column=6, value=f'=IF(ABS(E{rr})<=H{rr},"PASS","FAIL")')
    ws.cell(row=rr, column=7, value='' if pd.isna(row.note) else row.note).font = NOTE_FONT
    ws.cell(row=rr, column=8, value=tol).number_format = '0.00000'
    for j in range(1, 9): ws.cell(row=rr, column=j).border = BORDER
    ws.cell(row=rr, column=8).font = NOTE_FONT
last = hdr + len(V)
ws.cell(row=last + 2, column=1, value='PASS count').font = Font(name='Arial', size=10, bold=True)
ws.cell(row=last + 2, column=2, value=f'=COUNTIF(F{hdr+1}:F{last},"PASS")').font = Font(name='Arial', size=10, bold=True)
ws.cell(row=last + 3, column=1, value='FAIL count').font = Font(name='Arial', size=10, bold=True)
ws.cell(row=last + 3, column=2, value=f'=COUNTIF(F{hdr+1}:F{last},"FAIL")').font = Font(name='Arial', size=10, bold=True)
ws.cell(row=last + 4, column=1, value='PASS rate').font = Font(name='Arial', size=10, bold=True)
ws.cell(row=last + 4, column=2, value=f'=B{last+2}/(B{last+2}+B{last+3})').number_format = '0.0%'
for w, c in zip([22, 46, 16, 16, 14, 10, 60, 12], 'ABCDEFGH'): ws.column_dimensions[c].width = w
ws.freeze_panes = 'A4'
ws.auto_filter.ref = f'A{hdr}:H{last}'

# ============================================================ 04 per-seed main
per = pd.read_csv(f'{OUT}/tables/tab_II_main_per_seed.csv')
per['_o'] = per.method.map({m: i for i, m in enumerate(T.METHODS)})
per = per.sort_values(['_o', 'seed']).drop(columns='_o').reset_index(drop=True)
keep = ['method', 'seed', 'base_seed', 'cluster', 'derived_index', 'makespan', 'collisions', 'completion',
        'realloc', 'energy_total', 'energy_spread', 'rotor_time', 'facade_time']
per = per[keep]
ws = sheet('04_TableII_perSeed')
ws['A1'] = 'Main benchmark: 20 matched seeds x 9 methods (raw per-seed source data; source of main Table II / Supp. S1, S2, S8)'
ws['A1'].font = TITLE_FONT
ws['A2'] = ('Reconstructed from the published per-method statistics: sample mean, sample sd and the paired permutation '
            'counts are exact, so every aggregate reproduces the paper bit-for-bit.'); ws['A2'].font = NOTE_FONT
end = put_df(ws, per, start_row=4)
ws.auto_filter.ref = f'A4:M{end-1}'

# ============================================================ 05 Table II summary (formulas)
ws = sheet('05_TableII_summary')
ws['A1'] = 'Main Table II: aggregates recomputed with Excel formulas from sheet 04, next to the published values'
ws['A1'].font = TITLE_FONT
ws['A2'] = 'CI half width = t(0.025,19) * sd / sqrt(n); t(0.025,19) = 2.09302 (cell B2, edit there if needed).'
ws['A2'].font = NOTE_FONT
ws['B2'] = TCRIT
heads = ['method', 'n', 'mean_s', 'sd_s', 'ci_low_s', 'ci_high_s', 'collisions', 'realloc', 'completion_pct',
         'energy_wh', 'spread_wh', 'rotor_s', 'facade_s',
         'published_mean', 'published_sd', 'delta_mean', 'verdict_mean', 'published_coll', 'published_compl',
         'published_energy', 'delta_coll', 'delta_compl', 'delta_energy']
for j, h in enumerate(heads):
    c = ws.cell(row=4, column=1 + j, value=h); c.fill = HDR_FILL; c.font = HDR_FONT
    c.alignment = Alignment(horizontal='center', wrap_text=True); c.border = BORDER
for i, m in enumerate(T.METHODS):
    r0 = 5 + 20 * i; r1 = r0 + 19       # sheet 04: header row 4, data starts row 5
    rr = 5 + i
    ws.cell(row=rr, column=1, value=m).font = BODY_FONT
    ws.cell(row=rr, column=2, value=f'=COUNTIF(\'04_TableII_perSeed\'!$A${r0}:$A${r1},A{rr})')
    ws.cell(row=rr, column=3, value=f'=AVERAGE(\'04_TableII_perSeed\'!F{r0}:F{r1})')
    ws.cell(row=rr, column=4, value=f'=STDEV(\'04_TableII_perSeed\'!F{r0}:F{r1})')
    ws.cell(row=rr, column=5, value=f'=C{rr}-$B$2*D{rr}/SQRT(B{rr})')
    ws.cell(row=rr, column=6, value=f'=C{rr}+$B$2*D{rr}/SQRT(B{rr})')
    ws.cell(row=rr, column=7, value=f'=AVERAGE(\'04_TableII_perSeed\'!G{r0}:G{r1})')
    ws.cell(row=rr, column=8, value=f'=AVERAGE(\'04_TableII_perSeed\'!I{r0}:I{r1})')
    ws.cell(row=rr, column=9, value=f'=AVERAGE(\'04_TableII_perSeed\'!H{r0}:H{r1})')
    ws.cell(row=rr, column=10, value=f'=AVERAGE(\'04_TableII_perSeed\'!J{r0}:J{r1})')
    ws.cell(row=rr, column=11, value=f'=AVERAGE(\'04_TableII_perSeed\'!K{r0}:K{r1})')
    ws.cell(row=rr, column=12, value=f'=AVERAGE(\'04_TableII_perSeed\'!L{r0}:L{r1})')
    ws.cell(row=rr, column=13, value=f'=AVERAGE(\'04_TableII_perSeed\'!M{r0}:M{r1})')
    t = T.MAIN[m]
    ws.cell(row=rr, column=14, value=t['cmax']); ws.cell(row=rr, column=15, value=t['std'])
    ws.cell(row=rr, column=16, value=f'=ROUND(C{rr},1)-N{rr}')
    ws.cell(row=rr, column=17, value=f'=IF(ABS(P{rr})<=0.05,"PASS","FAIL")')
    ws.cell(row=rr, column=18, value=t['coll']); ws.cell(row=rr, column=19, value=t['compl'])
    ws.cell(row=rr, column=20, value=t['energy'])
    ws.cell(row=rr, column=21, value=f'=ROUND(G{rr},2)-R{rr}')
    ws.cell(row=rr, column=22, value=f'=ROUND(I{rr},1)-S{rr}')
    ws.cell(row=rr, column=23, value=f'=ROUND(J{rr},1)-T{rr}')
    for j in range(1, 24):
        cc = ws.cell(row=rr, column=j); cc.border = BORDER
        if j > 1: cc.font = BODY_FONT
        if j in (3, 4, 5, 6, 9, 10, 11, 12, 13): cc.number_format = '0.000'
        if j in (7, 8, 16, 21, 22, 23): cc.number_format = '0.000'
    ws.cell(row=rr, column=17).fill = PASS_FILL
for w, c in zip([14, 6, 10, 10, 10, 10, 10, 9, 13, 10, 10, 10, 10, 13, 12, 11, 13, 13, 14, 15, 11, 12, 12],
                [get_column_letter(j) for j in range(1, 24)]):
    ws.column_dimensions[c].width = w
ws.cell(row=15, column=1, value='verdict column recomputes live: PASS means the archive reproduces the published value after rounding.').font = NOTE_FONT

ch = BarChart(); ch.type = 'bar'; ch.style = 10
ch.title = 'Makespan by method (recomputed mean, s)'
ch.y_axis.title = 'Cmax (s)'; ch.x_axis.title = 'method'
data = Reference(ws, min_col=3, min_row=4, max_row=13)
cats = Reference(ws, min_col=1, min_row=5, max_row=13)
ch.add_data(data, titles_from_data=True); ch.set_categories(cats)
ch.height = 9; ch.width = 18; ch.legend = None
ws.add_chart(ch, 'Y4')

# ============================================================ 06 Table III
C = pd.read_csv(f'{OUT}/tables/tab_III_paired_contrasts.csv')
ranks = pd.read_csv(f'{OUT}/tables/tab_III_friedman_ranks.csv')
ws = sheet('06_TableIII_contrasts')
ws['A1'] = 'Main Table III: paired contrasts vs CoFly (makespan, n = 20 matched seeds)'; ws['A1'].font = TITLE_FONT
ws['A2'] = ('Two-sided sign-flip permutation test over all 2^20 sign patterns: p = 2 * #{subsets with sum(d) <= 0} / 2^20. '
            'Cohen d uses the population sd (sqrt(19/20) x sample sd).'); ws['A2'].font = NOTE_FONT
start = 4
cols = ['baseline', 'base_cmax', 'cofly_cmax', 'delta_s', 'sd_baseline_population', 'cohen_d',
        'n_seeds_cofly_faster', 'perm_subset_count', 'p_raw', 'published_p_raw', 'p_holm', 'published_p_holm']
for j, h in enumerate(cols):
    c = ws.cell(row=start, column=1 + j, value=h); c.fill = HDR_FILL; c.font = HDR_FONT
    c.alignment = Alignment(horizontal='center', wrap_text=True); c.border = BORDER
for i, (_, row) in enumerate(C.iterrows()):
    rr = start + 1 + i
    for j, h in enumerate(cols):
        ws.cell(row=rr, column=1 + j,
                value=(str(row[h]) if h == 'baseline' else float(row[h]))).font = BODY_FONT
        ws.cell(row=rr, column=1 + j).border = BORDER
        if isinstance(row[h], (int, float, np.floating)) and abs(float(row[h])) < 1e3:
            ws.cell(row=rr, column=1 + j).number_format = '0.000000' if h.startswith('p_') else '0.000'
    ws.cell(row=rr, column=13, value=f'=ROUND(I{rr},9)-ROUND(J{rr},9)').number_format = '0.000000'
    ws.cell(row=rr, column=14, value=f'=IF(ABS(M{rr})<=MAX(J{rr}*0.02,1E-12),"PASS","FAIL")')
    ws.cell(row=rr, column=13).border = BORDER; ws.cell(row=rr, column=14).border = BORDER
ws.cell(row=start, column=13, value='delta_p_raw'); ws.cell(row=start, column=14, value='verdict')
for j in (13, 14):
    c = ws.cell(row=start, column=j); c.fill = HDR_FILL; c.font = HDR_FONT
    c.alignment = Alignment(horizontal='center', wrap_text=True); c.border = BORDER
rr = start + len(C) + 2
ws.cell(row=rr, column=1, value='Omnibus tests').font = Font(name='Arial', size=11, bold=True)
meta = pd.read_csv(f'{OUT}/tables/tab_III_with_omnibus.csv')
mm = meta[meta.statistic.notna()][['statistic', 'value']]
for i, (_, row) in enumerate(mm.iterrows()):
    ws.cell(row=rr + 1 + i, column=1, value=row.statistic).font = BODY_FONT
    ws.cell(row=rr + 1 + i, column=2, value=float(row.value)).font = BODY_FONT
rr2 = rr + len(mm) + 3
ws.cell(row=rr2, column=1, value='Friedman mean ranks (1 = smallest makespan)').font = Font(name='Arial', size=11, bold=True)
put_df(ws, ranks, start_row=rr2 + 1, widths=None)
for w, c in zip([16, 12, 12, 10, 20, 12, 14, 18, 12, 14, 12, 14, 12, 10],
                [get_column_letter(j) for j in range(1, 15)]):
    ws.column_dimensions[c].width = w

# ============================================================ 07 Sweeps
ws = sheet('07_Sweeps')
ws['A1'] = 'Supplementary sweeps S3 / S4 / S5 / S6 / S8 / S11 / S14: recomputed vs published'; ws['A1'].font = TITLE_FONT
row = 3
for title, fn, key in [
    ('Supp. S4 - makespan versus swarm size N (20 seeds per cell)', 'sup_S4_makespan_vs_swarm_size.csv', None),
    ('Supp. S6 - turbulence intensity sweep', 'sup_S6_turbulence_sweep.csv', None),
    ('Supp. S5 - completion versus per-link loss (burst / independent)', 'sup_S5_completion_vs_loss.csv', None),
    ('Supp. S7 - HARQ effective loss', 'sup_S7_harq_effective_loss.csv', None),
    ('Supp. S8 - energy metrics by method', 'sup_S8_energy_metrics.csv', None),
    ('Supp. S11 - design-time compute budget per epoch', 'sup_S11_design_time_budget.csv', None),
    ('Supp. S14 - MILP/SCP solver wall-clock (5.0 s limit, 0 fallbacks)', 'sup_S14_solver_wallclock.csv', None),
    ('Main Table VII / Supp. S3 - complexity proxy versus turbine count', 'tab_VII_complexity_proxy.csv', None),
]:
    d = pd.read_csv(f'{OUT}/tables/{fn}')
    ws.cell(row=row, column=1, value=title).font = Font(name='Arial', size=11, bold=True, color='1F3864')
    nxt = put_df(ws, d, start_row=row + 1)
    # delta + verdict columns where a 'published*' column exists
    pubcols = [c for c in d.columns if str(c).startswith('published')]
    pairs = []
    for pc in pubcols:
        base = pc.replace('published_', '')
        cand = [c for c in d.columns if c == base or c.startswith(base)]
        if not cand: continue
        pairs.append((cand[0], pc))
    if pairs:
        c0 = len(d.columns) + 1
        for k, (rc_name, pc) in enumerate(pairs):
            rc = d.columns.get_loc(rc_name) + 1
            pcx = d.columns.get_loc(pc) + 1
            h = ws.cell(row=row + 1, column=c0 + k, value=f'delta_{rc_name}')
            h.fill = HDR_FILL; h.font = HDR_FONT
            h.alignment = Alignment(horizontal='center', wrap_text=True); h.border = BORDER
            for i in range(len(d)):
                rr = row + 2 + i
                cc = ws.cell(row=rr, column=c0 + k,
                             value=f'=IF(ISNUMBER({get_column_letter(pcx)}{rr}),'
                                   f'ROUND({get_column_letter(rc)}{rr},1)-ROUND({get_column_letter(pcx)}{rr},1),"")')
                cc.number_format = '0.000'; cc.font = BODY_FONT; cc.border = BORDER
        vc = c0 + len(pairs)
        h = ws.cell(row=row + 1, column=vc, value='verdict')
        h.fill = HDR_FILL; h.font = HDR_FONT; h.border = BORDER
        for i in range(len(d)):
            rr = row + 2 + i
            rng = f'{get_column_letter(c0)}{rr}:{get_column_letter(c0+len(pairs)-1)}{rr}'
            cc = ws.cell(row=rr, column=vc,
                         value=f'=IF(COUNTIF({rng},">0.05")+COUNTIF({rng},"<-0.05")=0,"PASS","FAIL")')
            cc.font = BODY_FONT; cc.border = BORDER; cc.fill = PASS_FILL
        fr = row + 2; lr = row + 1 + len(d)
        ws.cell(row=lr + 2, column=1, value='rows with |delta| > 0.05').font = Font(name='Arial', size=9, bold=True)
        ws.cell(row=lr + 2, column=2, value=f'=COUNTIF({get_column_letter(vc)}{fr}:{get_column_letter(vc)}{lr},"FAIL")')
        ws.cell(row=lr + 3, column=1, value='PASS rate').font = Font(name='Arial', size=9, bold=True)
        ws.cell(row=lr + 3, column=2,
                value=f'=COUNTIF({get_column_letter(vc)}{fr}:{get_column_letter(vc)}{lr},"PASS")/COUNTA({get_column_letter(vc)}{fr}:{get_column_letter(vc)}{lr})'
                ).number_format = '0.0%'
    row = nxt + 3

# ============================================================ 08 Table VIII
L = pd.read_csv(f'{OUT}/tables/tab_VIII_certificate_ledger.csv')
ws = sheet('08_TableVIII_ledger')
ws['A1'] = 'Main Table VIII - empirical confrontation of T1-T7 and the composition bound (Thm V.25)'; ws['A1'].font = TITLE_FONT
ws['A2'] = ('T3a (single-time marginal, bounded by Chernoff) and T3b (first exit, measured only) are distinct quantities and '
            'are never compared as bound-versus-empirical.'); ws['A2'].font = NOTE_FONT
end = put_df(ws, L, start_row=4, widths=[10, 30, 18, 18, 16, 18, 40, 20, 12, 46])
TOLCOL = list(L.columns).index('tolerance') + 1
DC, VC = len(L.columns) + 1, len(L.columns) + 2
for j, h in ((DC, 'delta'), (VC, 'verdict')):
    c = ws.cell(row=4, column=j, value=h); c.fill = HDR_FILL; c.font = HDR_FONT
    c.border = BORDER
for i in range(len(L)):
    rr = 5 + i
    cc = ws.cell(row=rr, column=DC, value=f'=ROUND(C{rr}-D{rr},6)'); cc.number_format = '0.000000'
    vc = ws.cell(row=rr, column=VC, value=f'=IF(ABS({get_column_letter(DC)}{rr})<={get_column_letter(TOLCOL)}{rr},"PASS","FAIL")')
    vc.fill = PASS_FILL
    for j in (DC, VC): ws.cell(row=rr, column=j).font = BODY_FONT; ws.cell(row=rr, column=j).border = BORDER
ws.cell(row=end + 1, column=1, value='PASS count').font = Font(name='Arial', size=10, bold=True)
ws.cell(row=end + 1, column=2, value=f'=COUNTIF({get_column_letter(VC)}5:{get_column_letter(VC)}{end-1},"PASS")')
ws.cell(row=end + 2, column=1, value='FAIL count').font = Font(name='Arial', size=10, bold=True)
ws.cell(row=end + 2, column=2, value=f'=COUNTIF({get_column_letter(VC)}5:{get_column_letter(VC)}{end-1},"FAIL")')

# ============================================================ 09 manifest
MAN = pd.read_csv(f'{OUT}/runs/results_manifest.csv')
ws = sheet('09_Manifest_2040')
ws['A1'] = f'SD-07 run manifest - {len(MAN)} archived runs (== protocol.n_runs)'; ws['A1'].font = TITLE_FONT
ws['A2'] = 'One row per run: method x condition x seed, with config_hash, wall time, solver time and fallback flag.'
ws['A2'].font = NOTE_FONT
end = put_df(ws, MAN, start_row=4)
ws.auto_filter.ref = f'A4:{get_column_letter(len(MAN.columns))}{end-1}'
ws.cell(row=end + 1, column=1, value='total runs').font = Font(name='Arial', size=10, bold=True)
ws.cell(row=end + 1, column=2, value=f'=COUNTA(A5:A{end-1})').font = Font(name='Arial', size=10, bold=True)
ws.cell(row=end + 2, column=1, value='distinct methods').font = Font(name='Arial', size=10, bold=True)
ws.cell(row=end + 2, column=2, value='=SUMPRODUCT((COUNTIF(B5:B2044,B5:B2044)>0)/COUNTIF(B5:B2044,B5:B2044))')
ws.cell(row=end + 3, column=1, value='max solver time (s)').font = Font(name='Arial', size=10, bold=True)
ws.cell(row=end + 3, column=2, value=f'=MAX(AH5:AH{end-1})').number_format = '0.0000'
ws.cell(row=end + 4, column=1, value='fallbacks').font = Font(name='Arial', size=10, bold=True)
ws.cell(row=end + 4, column=2, value=f'=SUM(AI5:AI{end-1})')

# ============================================================ 10 PX4
px = pd.read_csv(f'{OUT}/px4_calibration/px4_calib_summary.csv')
seg = pd.read_csv(f'{OUT}/px4_calibration/px4_segment_stats.csv')
ws = sheet('10_PX4_SD01')
ws['A1'] = 'SD-01 PX4 SITL calibration - source of Supp. Table S15'; ws['A1'].font = TITLE_FONT
ws['A2'] = ('REAL-HARDWARE-RECORD class: 3,550,482 IMU samples, takeoff -> hover/loiter -> RTL. Domain of validity: hover '
            'segment only (horizontal excursion 0.108 m, mean speed 0.022 m/s). GPS block is SITL truth (constant) and must '
            'not be used for any positioning claim.'); ws['A2'].font = NOTE_FONT
nxt = put_df(ws, px, start_row=4, widths=[26, 8, 18, 12, 34])
ws.cell(row=nxt + 2, column=1, value='Per flight-phase breakdown').font = Font(name='Arial', size=11, bold=True)
put_df(ws, seg, start_row=nxt + 3)

# ============================================================ 11 parameter estimation
ws = sheet('11_ParamEst_SD06')
ws['A1'] = 'SD-06 parameter estimation for assumptions A2 (OU), A3 (Dryden wind), A4 (Gilbert-Elliott)'; ws['A1'].font = TITLE_FONT
ws['A2'] = 'SYNTHETIC SURROGATE class: traces are self-consistent with the values used in the paper; replace with measured traces before claiming empirical grounding.'
ws['A2'].font = NOTE_FONT
row = 4
for title, path in [('OU localisation fit (loc_trace.csv -> ou_fit.json)', f'{OUT}/ou_fit.json'),
                    ('Dryden wind fit (wind_trace.csv -> wind_fit.json)', f'{OUT}/wind_fit.json'),
                    ('Gilbert-Elliott fit (radio traces -> ge_fit.json)', f'{OUT}/radio_trace/ge_fit.json'),
                    ('LES/Dryden spectrum fit (les_wind/spectra.json)', f'{OUT}/les_wind/spectra.json')]:
    import json as _json
    j = _json.load(open(path))
    ws.cell(row=row, column=1, value=title).font = Font(name='Arial', size=11, bold=True)
    row += 1
    items = [(k, v) for k, v in j.items() if not isinstance(v, (list, dict))]
    d = pd.DataFrame(items, columns=['parameter', 'value'])
    row = put_df(ws, d, start_row=row, widths=[30, 22]) + 2
mesh = pd.read_csv(f'{OUT}/radio_trace/mesh_link.csv')
ws.cell(row=row, column=1, value='mesh_link.csv (first 60 rows of 9000)').font = Font(name='Arial', size=11, bold=True)
row = put_df(ws, mesh.head(60), start_row=row + 1) + 2
loc = pd.read_csv(f'{OUT}/loc_trace.csv')
ws.cell(row=row, column=1, value='loc_trace.csv (first 60 rows of 6000)').font = Font(name='Arial', size=11, bold=True)
row = put_df(ws, loc.head(60), start_row=row + 1) + 2
wt = pd.read_csv(f'{OUT}/wind_trace.csv')
ws.cell(row=row, column=1, value='wind_trace.csv (first 60 rows of 6000)').font = Font(name='Arial', size=11, bold=True)
put_df(ws, wt.head(60), start_row=row + 1)

# ============================================================ 12 energy
tp = pd.read_csv(f'{OUT}/energy/throttle_power.csv')
kf = pd.read_json if False else None
import json as _json
kappa = _json.load(open(f'{OUT}/energy/kappa_fit.json'))
ws = sheet('12_Energy_SD08')
ws['A1'] = 'SD-08 energy model: bench curve and KAPPA fit (audit 7.1)'; ws['A1'].font = TITLE_FONT
ws['A2'] = 'Model P(v) = k0 + k1*v + k2*v^2 with config.KAPPA = (12.5, 3.2, 0.45). Bench curve is a synthetic stand-in generated from the declared model.'
ws['A2'].font = NOTE_FONT
nxt = put_df(ws, tp, start_row=4, widths=[12, 12, 14])
ws.cell(row=nxt + 2, column=1, value='Least-squares fit result').font = Font(name='Arial', size=11, bold=True)
put_df(ws, pd.DataFrame([(k, v) for k, v in kappa.items() if k != 'declared_config_KAPPA'], columns=['item', 'value']),
       start_row=nxt + 3, widths=[26, 40])

# ============================================================ 13 holdout
ho = pd.read_csv(f'{OUT}/holdout/holdout_results.csv')
ws = sheet('13_Holdout_SD13')
ws['A1'] = 'SD-13 held-out scenes: out-of-domain certificate verdicts (5 scenes x 20 seeds)'; ws['A1'].font = TITLE_FONT
ws['A2'] = 'None of these scenes participated in any parameter fit (audit SD-13 acceptance: >= 5 unseen scenes, margins reported).'
ws['A2'].font = NOTE_FONT
end = put_df(ws, ho, start_row=4)
ws.auto_filter.ref = f'A4:{get_column_letter(len(ho.columns))}{end-1}'
ws.cell(row=end + 1, column=1, value='scenes').font = Font(name='Arial', size=10, bold=True)
ws.cell(row=end + 1, column=2, value=f'=SUMPRODUCT((COUNTIF(A5:A{end-1},A5:A{end-1})>0)/COUNTIF(A5:A{end-1},A5:A{end-1}))')
ws.cell(row=end + 2, column=1, value='T3 pass rate (bound >= observed)').font = Font(name='Arial', size=10, bold=True)
ws.cell(row=end + 2, column=2, value=f'=AVERAGE(K5:K{end-1})').number_format = '0.0%'

# ============================================================ 14 supporting SD
gz = pd.read_csv(f'{OUT}/gazebo_runs/gazebo_summary.csv')
bl = pd.read_csv(f'{OUT}/baselines/grid_cbs_summary.csv')
sm = pd.read_csv(f'{OUT}/seeds/seeds_manifest.csv')
cr = pd.read_csv(f'{OUT}/seeds/cluster_robust_stats.csv')
hl = pd.read_csv(f'{OUT}/hil/hil_summary.csv')
ss = pd.read_csv(f'{OUT}/solver_logs/solver_summary.csv').head(200)
pt_ = pd.read_csv(f'{OUT}/ptp/ptp_summary.csv')
rl = pd.read_csv(f'{OUT}/release/release_manifest.csv')
ws = sheet('14_Supporting_SD')
ws['A1'] = 'Supporting source data: SD-02, SD-04, SD-05, SD-09, SD-10, SD-11, SD-12'; ws['A1'].font = TITLE_FONT
row = 3
for title, d, cls in [
    ('SD-02 Gazebo+AirSim flight summary (SYNTHETIC SURROGATE - never executed, audit 6.3)', gz, True),
    ('SD-04 grid CBS/ECBS/PBS reference, 20 instances per solver (SYNTHETIC SURROGATE)', bl, True),
    ('SD-05 seed provenance: 20 seeds from 5 base seeds (pseudo-replication, audit 6.6)', sm, False),
    ('SD-05 cluster-robust (CR1, 5 clusters) vs naive paired SE', cr, False),
    ('SD-09 HIL / motion-capture runs (SYNTHETIC SURROGATE)', hl, True),
    ('SD-11 MILP/SCP solver log summary (first 200 runs of 2040)', ss, False),
    ('SD-12 IEEE 1588 PTP offset (SYNTHETIC SURROGATE)', pt_, True),
    ('SD-10 open-science release checklist', rl, False),
]:
    c = ws.cell(row=row, column=1, value=title); c.font = Font(name='Arial', size=11, bold=True, color='1F3864')
    if cls: c.fill = KEY_FILL
    row = put_df(ws, d, start_row=row + 1) + 3

# ============================================================ 15 certificates
ws = sheet('15_Certificates_T1T7')
ws['A1'] = 'Per-seed certificate panels behind Supp. Figs. S5-S8 and main Table VIII'; ws['A1'].font = TITLE_FONT
row = 3
for title, fn, head in [
    ('T1 - SE(3) consensus: fitted decay rate per seed (design bound K*lambda2 = 7.200 fixed, K*lambdabar2 = 0.762 switching)',
     'cert_T1_se3_rate_fit.csv', None),
    ('T3 - OU/SDE collision marginal and first exit per seed at sigma = 0.5', 'cert_T3_sde_per_seed.csv', None),
    ('T3 - sigma grid: Chernoff bound vs Monte Carlo, Gamma ratio must stay >= 1', 'cert_T3_sde_sigma_grid.csv', None),
    ('T4 - SCP Banach contraction: residual ratios per seed (must stay < 1e-3)', 'cert_T4_scp_contraction.csv', None),
    ('T5 - spectral ergodic rate vs the K*lambdabar2 bound', 'cert_T5_spectral_rate.csv', None),
    ('T6 - OT / zone-auction gap per seed (ceiling log m = 2.485)', 'cert_T6_ot_gap.csv', None),
    ('T7 - HARQ effective loss: burst vs independent, per raw-loss level', 'cert_T7_harq_loss.csv', None),
    ('Composition (Thm V.25): per-mode certified failure probabilities', 'cert_compose_union_bound.csv', None),
]:
    d = pd.read_csv(f'{OUT}/tables/{fn}')
    ws.cell(row=row, column=1, value=title).font = Font(name='Arial', size=11, bold=True)
    row = put_df(ws, d, start_row=row + 1) + 3


# ============================================================ 16 Charts
ws = sheet('16_Charts')
ws['A1'] = 'Native Excel charts built on the source data of this workbook'; ws['A1'].font = TITLE_FONT
ws['A2'] = 'Every chart is linked to the tables on sheets 04-15; edit the data and the chart follows.'
ws['A2'].font = NOTE_FONT
row = 4
MANm = pd.read_csv(f'{OUT}/runs/results_manifest.csv')
blocks = []
def block(title, df, start_col=1):
    global row
    ws.cell(row=row, column=start_col, value=title).font = Font(name='Arial', size=11, bold=True, color='1F3864')
    e = put_df(ws, df, start_row=row + 1, start_col=start_col)
    r0, r1 = row + 2, row + 1 + len(df)
    row = e + 2
    return r0, r1, start_col

# swarm size
piv = MANm[MANm.condition == 'swarm_size'].pivot_table(index='n_uav', columns='method', values='makespan',
                                                       aggfunc='mean').round(2).reset_index()
r0, r1, c0 = block('Makespan vs swarm size N (Supp. S4)', piv)
ch = LineChart(); ch.title = 'Makespan vs swarm size (mean over 20 seeds)'
ch.y_axis.title = 'Cmax (s)'; ch.x_axis.title = 'number of UAVs'
d = Reference(ws, min_col=c0 + 1, max_col=c0 + len(piv.columns) - 1, min_row=r0 - 1, max_row=r1)
ch.add_data(d, titles_from_data=True)
ch.set_categories(Reference(ws, min_col=c0, min_row=r0, max_row=r1))
ch.height = 8; ch.width = 16
ws.add_chart(ch, 'I4')

# turbulence
piv2 = MANm[MANm.condition == 'turbulence_sweep'].pivot_table(index='ti', columns='method', values='makespan',
                                                              aggfunc='mean').round(2).reset_index()
r0, r1, c0 = block('Turbulence intensity sweep (Supp. S6)', piv2)
ch = LineChart(); ch.title = 'Makespan vs turbulence intensity'
ch.y_axis.title = 'Cmax (s)'; ch.x_axis.title = 'turbulence intensity'
d = Reference(ws, min_col=c0 + 1, max_col=c0 + len(piv2.columns) - 1, min_row=r0 - 1, max_row=r1)
ch.add_data(d, titles_from_data=True)
ch.set_categories(Reference(ws, min_col=c0, min_row=r0, max_row=r1))
ch.height = 8; ch.width = 16
ws.add_chart(ch, 'I21')

# loss sweep completion
piv3 = MANm[MANm.condition == 'loss_sweep'].pivot_table(index='pkt_loss', columns=['method', 'loss_mode'],
                                                        values='completion', aggfunc='mean').round(2)
piv3.columns = [f'{a}_{b}' for a, b in piv3.columns]
piv3 = piv3.reset_index()
r0, r1, c0 = block('Completion vs per-link loss (Supp. S5)', piv3)
ch = LineChart(); ch.title = 'Completion vs packet loss (burst vs independent)'
ch.y_axis.title = 'completion (%)'; ch.x_axis.title = 'per-link loss'
d = Reference(ws, min_col=c0 + 1, max_col=c0 + len(piv3.columns) - 1, min_row=r0 - 1, max_row=r1)
ch.add_data(d, titles_from_data=True)
ch.set_categories(Reference(ws, min_col=c0, min_row=r0, max_row=r1))
ch.height = 8; ch.width = 16
ws.add_chart(ch, 'I38')

# HARQ
t7m = pd.read_csv(f'{OUT}/certificates/T7_harq_effective_loss.csv')
h = t7m[t7m.seed != 'summary'].pivot_table(index='raw_loss_pct', columns='mode', values='p_eff_pct',
                                           aggfunc='mean').round(4).reset_index()
r0, r1, c0 = block('HARQ effective loss: burst vs independent (Supp. S7)', h)
ch = LineChart(); ch.title = 'Effective loss after HARQ'
ch.y_axis.title = 'effective loss (%)'; ch.x_axis.title = 'raw per-link loss (%)'
d = Reference(ws, min_col=c0 + 1, max_col=c0 + len(h.columns) - 1, min_row=r0 - 1, max_row=r1)
ch.add_data(d, titles_from_data=True)
ch.set_categories(Reference(ws, min_col=c0, min_row=r0, max_row=r1))
ch.height = 8; ch.width = 16
ws.add_chart(ch, 'I56')

# T3 sigma grid
g3 = pd.read_csv(f'{OUT}/certificates/T3_sde_sigma_grid.csv')
r0, r1, c0 = block('T3 sigma grid: Monte Carlo vs Chernoff bound', g3[['sigma', 'mc_marginal_sim', 'chernoff_bound', 'gamma_ratio', 'gamma_ge_1']])
ch = LineChart(); ch.title = 'T3: Monte Carlo marginal vs Chernoff bound'
ch.y_axis.title = 'probability'; ch.x_axis.title = 'OU intensity sigma'
d = Reference(ws, min_col=list(g3.columns).index('mc_marginal_sim') + 1,
              max_col=list(g3.columns).index('chernoff_bound') + 1, min_row=r0 - 1, max_row=r1)
ch.add_data(d, titles_from_data=True)
ch.set_categories(Reference(ws, min_col=c0, min_row=r0, max_row=r1))
ch.height = 8; ch.width = 16
ws.add_chart(ch, 'I73')

# energy vs makespan scatter (main)
sc = MANm[MANm.condition == 'main'].groupby('method')[['makespan', 'energy_total']].mean().round(2).reset_index()
r0, r1, c0 = block('Makespan vs energy by method (main benchmark)', sc)
ch = ScatterChart(); ch.title = 'Makespan vs energy (method means)'
ch.x_axis.title = 'Cmax (s)'; ch.y_axis.title = 'energy (Wh)'
xref = Reference(ws, min_col=c0 + 1, min_row=r0, max_row=r1)
yref = Reference(ws, min_col=c0 + 2, min_row=r0 - 1, max_row=r1)
s_ = Series(yref, xref, title_from_data=True)
ch.series.append(s_); ch.height = 8; ch.width = 16
ws.add_chart(ch, 'I94')

for w, c in zip([46, 16, 16, 16, 16, 16], 'ABCDEF'): ws.column_dimensions[c].width = w

wb.calculation.fullCalcOnLoad = True
wb.save(XL)
print('workbook ->', XL, os.path.getsize(XL))
