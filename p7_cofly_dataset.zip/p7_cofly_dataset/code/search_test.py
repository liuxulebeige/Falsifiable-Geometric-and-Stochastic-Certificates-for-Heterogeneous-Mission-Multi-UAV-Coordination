import numpy as np, sys, time
sys.path.insert(0,'.')
from core import *

rng = np.random.default_rng(11)
x = 919.8 + 84.7*stdz(rng.standard_normal(20))

def search(target, mean, sd, rng, trials=8, coarse=401, fine=3000):
    best = None
    for tr in range(trials):
        v = rng.standard_normal(20); u = rng.standard_normal(20)
        for t in np.linspace(-3,3,coarse):
            y = mean + sd*stdz(v+t*u); c = subset_count(y-x)
            if best is None or abs(c-target) < abs(best[0]-target):
                best = (c, t, v, u)
    c0, t0, v, u = best
    best = (c0, t0)
    for t in np.linspace(t0-0.08, t0+0.08, fine):
        y = mean + sd*stdz(v+t*u); c = subset_count(y-x)
        if abs(c-target) < abs(best[0]-target): best = (c, t)
        if best[0] == target: break
    return best

t0=time.time()
for name, tgt, mu, sd in [('centralised',307,1090.7,159.8), ('cbs',25375,973.3,80.3),
                          ('marl',43306,964.9,80.3), ('ecbs',312375,925.4,116.6)]:
    c,t = search(tgt, mu, sd, rng)
    print(name, 'target', tgt, 'got', c, 't', round(t,4), 'p', f'{perm_p(c):.3e}', 'elapsed', round(time.time()-t0,1))
