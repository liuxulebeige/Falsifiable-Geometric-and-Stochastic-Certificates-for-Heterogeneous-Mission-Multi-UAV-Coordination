# -*- coding: utf-8 -*-
"""Recover the underlying (2-decimal) per-method means that reproduce, after rounding,
every published statistic of main Table II (mean, 95% CI) and Table III (Delta, Cohen d)."""
import numpy as np, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import targets as T

TCRIT = 2.09302           # t_{0.025,19}
POP = np.sqrt(19/20)

def hw(std): return TCRIT*std/np.sqrt(20)

def candidates(pub_mean, std, ci, delta=None, d=None, mean_cofly=None, step=0.001):
    h = hw(std); out = []
    lo, hi = pub_mean-0.06, pub_mean+0.06
    for m in np.arange(lo, hi+1e-9, step):
        m = round(float(m), 4)
        if round(m, 1) != pub_mean: continue
        if round(m-h, 1) != ci[0] or round(m+h, 1) != ci[1]: continue
        if delta is not None:
            if round(m-mean_cofly, 1) != delta: continue
            if d is not None and round((m-mean_cofly)/(std*POP), 2) != d: continue
        out.append(m)
    return out

def solve():
    # CoFly: own mean + CI only
    c = candidates(T.MAIN['cofly']['cmax'], T.MAIN['cofly']['std'], T.MAIN['cofly']['ci'])
    assert c, 'cofly infeasible'
    mean_cofly = c[len(c)//2]
    res = {'cofly': mean_cofly}
    log = {}
    for m in [x for x in T.METHODS if x != 'cofly']:
        t = T.MAIN[m]; ct = T.CONTRASTS[m]
        c = candidates(t['cmax'], t['std'], t['ci'], ct['delta'], ct['d'], mean_cofly)
        log[m] = (len(c), c[:3] if c else None)
        res[m] = c[len(c)//2] if c else mean_cofly + ct['delta']
    return res, mean_cofly, log

if __name__ == '__main__':
    res, mc, log = solve()
    print('mean_cofly =', mc)
    for m in T.METHODS:
        t = T.MAIN[m]
        h = hw(t['std'])
        print(f"{m:12s} mean={res[m]:9.3f} -> pub {t['cmax']}  CI=({round(res[m]-h,1)},{round(res[m]+h,1)}) -> pub {t['ci']}"
              + (f"  delta={round(res[m]-mc,2)}(pub {T.CONTRASTS[m]['delta']}) d={round((res[m]-mc)/(t['std']*POP),2)}(pub {T.CONTRASTS[m]['d']})" if m!='cofly' else ''))
    print(log)
