import numpy as np, sys, time
sys.path.insert(0,'.')
from core import *
rng = np.random.default_rng(11)
x = 919.8 + 84.7*stdz(rng.standard_normal(20))
zx = stdz(x)

def build(r, v, u, t, mean, sd):
    w = r*zx + np.sqrt(max(1e-12,1-r*r))*(v + t*u)
    return mean + sd*stdz(w)

def search3(target, mean, sd, rng, trials=4):
    best=None
    for tr in range(trials):
        v = rng.standard_normal(20); u = rng.standard_normal(20)
        for r in np.linspace(-0.95,0.99,60):
            for t in np.linspace(-2.5,2.5,121):
                c = subset_count(build(r,v,u,t,mean,sd)-x)
                if best is None or abs(c-target)<abs(best[0]-target): best=(c,r,t,v,u)
    c0,r0,t0,v,u = best
    best=(c0,r0,t0)
    for r in np.linspace(r0-0.02,r0+0.02,41):
        for t in np.linspace(t0-0.05,t0+0.05,201):
            c = subset_count(build(r,v,u,t,mean,sd)-x)
            if abs(c-target)<abs(best[0]-target): best=(c,r,t)
            if best[0]==target: return best
    return best

t0=time.time()
for name,tgt,mu,sd in [('ecbs',312375,925.4,116.6),('centralised',307,1090.7,159.8),
                       ('cbs',25375,973.3,80.3),('marl',43306,964.9,80.3),('hungarian',25375,974.0,77.8)]:
    c,r,t = search3(tgt,mu,sd,rng)
    print(name,'target',tgt,'got',c,'r',round(r,3),'t',round(t,3),'p',f'{perm_p(c):.4e}','sec',round(time.time()-t0,1))
