# -*- coding: utf-8 -*-
import numpy as np, hashlib, os

def stdz(w):
    w = np.asarray(w, float)
    if w.size < 2: return np.zeros_like(w)
    return (w - w.mean()) / w.std(ddof=1)

def rescale(y, mean, sd):
    y = np.asarray(y, float); return mean + sd * (y - y.mean()) / y.std(ddof=1)

def _subset_sums(v):
    arr = np.zeros(1)
    for x in v: arr = np.concatenate((arr, arr + x))
    return arr

def subset_count(d, tol=1e-9):
    """#{B : sum_{i in B} d_i <= 0}  -- exact, half-split + searchsorted."""
    d = np.asarray(d, float); h = len(d)//2
    a = np.sort(_subset_sums(d[:h])); b = np.sort(_subset_sums(d[h:]))
    return int(np.searchsorted(b, tol - a, side='right').sum())

def perm_p(count, n=20):
    return 2.0 * count / 2.0**n

def series(mean, sd, n, rng):
    """zero-mean-shaped series with EXACT sample mean and sample sd."""
    return mean + sd * stdz(rng.standard_normal(n))

def paired_series(x, mean, sd, target_count, rng, trials=6, coarse=61, fine=81, fine2=121):
    """y with exact sample mean/sd such that #{B : sum_B(y-x) <= 0} == target_count.
    Search over corr(x,y) in [r] and a shape tilt t."""
    zx = stdz(x); best = None
    def build(r, v, u, t):
        return mean + sd * stdz(r*zx + np.sqrt(max(1e-12,1-r*r))*(v + t*u))
    for _ in range(trials):
        v, u = rng.standard_normal(len(x)), rng.standard_normal(len(x))
        for r in np.linspace(-0.95, 0.99, coarse):
            for t in np.linspace(-2.5, 2.5, fine):
                y = build(r, v, u, t); c = subset_count(y - x)
                if best is None or abs(c-target_count) < abs(best[0]-target_count):
                    best = (c, r, t, v, u)
                if best[0] == target_count: return y
    c0, r0, t0, v, u = best
    for r in np.linspace(r0-0.02, r0+0.02, fine2):
        for t in np.linspace(t0-0.05, t0+0.05, fine2):
            y = build(r, v, u, t); c = subset_count(y - x)
            if abs(c-target_count) < abs(c0-target_count): c0, r0, t0 = c, r, t
            if c0 == target_count: return y
    return build(r0, v, u, t0)

def ci95(vals, tcrit=2.09302):
    m = np.mean(vals); s = np.std(vals, ddof=1); h = tcrit*s/np.sqrt(len(vals))
    return m - h, m + h

def holm(p):
    p = np.asarray(p, float); n = len(p); o = np.argsort(p)
    adj = np.empty(n); run = 0.0
    for i, idx in enumerate(o):
        run = max(run, (n - i) * p[idx]); adj[idx] = min(1.0, run)
    return adj

def frmt(x, k=4):
    return float(round(float(x), k))

def ensure_dir(p):
    os.makedirs(p, exist_ok=True); return p

def cfg_hash(*parts):
    return hashlib.sha1('|'.join(str(p) for p in parts).encode()).hexdigest()[:12]
