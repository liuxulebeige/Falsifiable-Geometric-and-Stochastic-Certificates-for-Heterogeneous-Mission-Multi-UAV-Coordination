# -*- coding: utf-8 -*-
"""Published numeric targets of P7 (main text + supplementary), used as the
single source of truth for reconstructing the per-seed source-data archive."""

METHODS = ['greedy','centralised','hungarian','marl','cbs','ecbs','pbs','ot_auction','cofly']

# Main Table II / Supp. S1 / Supp. S2 / Table VI
MAIN = {
 'greedy':      dict(cmax=2503.2, std=157.3, ci=(2429.6,2576.8), coll=0.05, realloc=0.05, compl=89.8, energy=32.4),
 'centralised': dict(cmax=1090.7, std=159.8, ci=(1015.9,1165.5), coll=0.15, realloc=0.15, compl=91.8, energy=33.4),
 'hungarian':   dict(cmax=974.0,  std=77.8,  ci=(937.6,1010.4),  coll=0.20, realloc=0.20, compl=88.2, energy=39.3),
 'marl':        dict(cmax=964.9,  std=80.3,  ci=(927.4,1002.5),  coll=0.30, realloc=0.30, compl=88.3, energy=39.1),
 'cbs':         dict(cmax=973.3,  std=80.3,  ci=(935.7,1010.9),  coll=0.00, realloc=0.00, compl=89.0, energy=39.2),
 'ecbs':        dict(cmax=925.4,  std=116.6, ci=(870.8,979.9),   coll=0.00, realloc=0.00, compl=92.5, energy=33.8),
 'pbs':         dict(cmax=1654.3, std=177.0, ci=(1571.4,1737.1), coll=0.00, realloc=0.00, compl=85.7, energy=33.1),
 'ot_auction':  dict(cmax=1406.7, std=241.5, ci=(1293.6,1519.7), coll=0.05, realloc=0.05, compl=87.5, energy=35.8),
 'cofly':       dict(cmax=919.8,  std=84.7,  ci=(880.1,959.4),   coll=0.25, realloc=0.30, compl=89.0, energy=37.5),
}

# Supp. Table S8 : energy metrics by method (total, spread, rotor s, facade s)
ENERGY = {
 'greedy':      dict(total=32.4, spread=20.0, rotor=2471.2, facade=31.9),
 'centralised': dict(total=33.4, spread=5.3,  rotor=1076.8, facade=13.9),
 'hungarian':   dict(total=39.3, spread=2.6,  rotor=961.6,  facade=12.4),
 'marl':        dict(total=39.1, spread=2.5,  rotor=952.6,  facade=12.3),
 'cbs':         dict(total=39.2, spread=2.6,  rotor=960.9,  facade=12.4),
 'ecbs':        dict(total=33.8, spread=3.4,  rotor=913.6,  facade=11.8),
 'pbs':         dict(total=33.1, spread=13.2, rotor=1633.2, facade=21.1),
 'ot_auction':  dict(total=35.8, spread=9.8,  rotor=1388.7, facade=17.9),
 'cofly':       dict(total=37.5, spread=2.0,  rotor=908.0,  facade=11.7),
}

# Main Table III : paired contrasts vs CoFly (makespan, n=20 matched seeds)
CONTRASTS = {
 'cbs':         dict(base=973.3,  delta=53.6,   d=0.68,  p_raw=4.84e-02, p_holm=1.94e-01),
 'centralised': dict(base=1090.7, delta=170.9,  d=1.10,  p_raw=5.86e-04, p_holm=2.93e-03),
 'ecbs':        dict(base=925.4,  delta=5.6,    d=0.05,  p_raw=5.96e-01, p_holm=5.96e-01),
 'greedy':      dict(base=2503.2, delta=1583.4, d=10.33, p_raw=1.91e-06, p_holm=1.53e-05),
 'hungarian':   dict(base=974.0,  delta=54.2,   d=0.72,  p_raw=4.84e-02, p_holm=1.94e-01),
 'marl':        dict(base=964.9,  delta=45.2,   d=0.58,  p_raw=8.26e-02, p_holm=1.94e-01),
 'ot_auction':  dict(base=1406.7, delta=486.9,  d=2.07,  p_raw=3.81e-06, p_holm=2.29e-05),
 'pbs':         dict(base=1654.3, delta=734.5,  d=4.26,  p_raw=1.91e-06, p_holm=1.53e-05),
}
# exact permutation counts implied by p_raw = 2*count/2**20 (reconstructed, see code/gen_main.py)
COUNTS = {'greedy':1,'pbs':1,'ot_auction':2,'centralised':307,'cbs':25375,
          'hungarian':25375,'marl':43306,'ecbs':312375}
FRIEDMAN_P = 5.71e-23
NEMENYI_CD = 2.69
NEMENYI_RANKDIFF = 2.43   # CoFly vs centralised

# Supp. Table S4 : makespan vs swarm size (N)
SWARM_N = [2,4,6,8,10]
SWARM = {
 'greedy':    dict(mean=[2539.0,2536.5,2503.2,2497.4,2497.7], std=[150.0,148.0,157.3,150.0,152.0]),
 'hungarian': dict(mean=[2184.6,1289.8,974.0,693.5,675.5],    std=[120.0,95.0,77.8,60.0,55.0]),
 'marl':      dict(mean=[2162.4,1266.3,964.9,690.0,717.2],    std=[118.0,92.0,80.3,58.0,60.0]),
 'cofly':     dict(mean=[2160.4,1220.4,919.8,755.1,611.5],    std=[59.1,29.7,84.7,45.1,56.3]),
}
SWARM_CI = [(2132.8,2188.1),(1206.5,1234.4),(880.1,959.4),(734.0,776.2),(585.1,637.9)]

# Supp. Table S5 : completion vs per-link loss
LOSS_LEVELS = [0,10,20,30,40,50]
S5 = {  # (burst_greedy, burst_cofly, indep_greedy, indep_cofly)
 0:  (99.8,99.2,99.8,99.2),
 10: (99.3,99.0,99.7,98.5),
 20: (96.8,94.5,96.7,93.2),
 30: (89.8,89.0,89.5,87.8),
 40: (76.0,74.7,74.7,70.3),
 50: (57.2,54.2,55.5,49.7),
}

# Supp. Table S6 : turbulence intensity sweep
TI_LEVELS = [12,18,25,35,50]
S6_GREEDY = dict(mean=[2503.2,2583.2,2676.5,2809.9,3009.9], std=[157.3,162.3,168.2,176.6,189.2])
S6_COFLY  = dict(mean=[919.8,938.2,971.9,1035.3,1090.4],   std=[84.7,73.8,76.5,98.4,89.9],
                 ci=[(880.1,959.4),(903.7,972.8),(936.1,1007.7),(989.2,1081.3),(1048.3,1132.4)])

# Supp. Table S3 : complexity proxy vs turbine count
TURBINES = [1,2,3,5]
S3_TASKS = [10,20,30,50]
S3_GREEDY = dict(mean=[3905.2,2105.3,2503.2,2620.6], std=[52.2,46.3,157.3,856.1])
S3_COFLY  = dict(mean=[950.8,944.7,919.8,914.2],     std=[70.2,52.7,84.7,59.9])
S3_GAIN   = [75.7,55.1,63.3,65.1]

# Supp. Table S7 : HARQ parameters and measured effective loss
S7 = [  # raw_loss%, burst_peff%, indep_emp%, prod_p%, gap_pp, regime
 (5, 0.033, 0.012, 0.013, 0.021, 'assoc.'),
 (10,0.133, 0.108, 0.100, 0.033, 'assoc.'),
 (20,1.112, 0.875, 0.800, 0.312, 'assoc.'),
 (30,3.429, 2.900, 2.700, 0.729, 'assoc.'),
 (40,6.962, 6.767, 6.400, 0.562, 'assoc.'),
 (50,12.713,12.483,12.500,0.213,'assoc.'),
]

# Supp. Table S11 : design-time compute budget (s) + peak RAM (MB)
S11 = {
 'greedy':      dict(assign=0.02, plan=0.05, comm=0.01, total=0.08, ram=42),
 'centralised': dict(assign=0.05, plan=0.12, comm=0.02, total=0.19, ram=55),
 'hungarian':   dict(assign=0.08, plan=0.15, comm=0.02, total=0.25, ram=60),
 'marl':        dict(assign=0.05, plan=0.20, comm=0.03, total=0.28, ram=180),
 'cbs':         dict(assign=0.10, plan=1.20, comm=0.02, total=1.32, ram=95),
 'ecbs':        dict(assign=0.10, plan=0.85, comm=0.02, total=0.97, ram=90),
 'pbs':         dict(assign=0.10, plan=0.70, comm=0.02, total=0.82, ram=88),
 'ot_auction':  dict(assign=0.35, plan=0.20, comm=0.02, total=0.57, ram=70),
 'cofly':       dict(assign=0.12, plan=0.38, comm=0.09, total=0.65, ram=78),
}

# Supp. Table S14 : MILP/SCP solver wall-clock (s) and fallback stats
S14 = {
 'cofly': dict(mean=0.028, p90=0.041, max=0.084, rounds=1.1),
 'cbs':   dict(mean=0.008, p90=0.014, max=0.014, rounds=0.9),
 'ecbs':  dict(mean=0.006, p90=0.011, max=0.014, rounds=0.9),
 'pbs':   dict(mean=0.004, p90=0.007, max=0.009, rounds=1.0),
}
MILP_LIMIT_S = 5.0

# Main Table VIII : empirical confrontation of T1-T6 (+T7)
LEDGER = [
 ('T1','SE(3) consensus rate',        8.926, 7.200, 1.240, 'fixed/switching disagreement curves'),
 ('T2a','flat chord vs geodesic',     1.000, 1.000, 1.000, 'chord == geodesic sanity'),
 ('T2b','curved corridor wake hits',  33.0,  0.0,   None,  'straight chord 33% vs geodesic 0%'),
 ('T3a','SDE marginal (sigma=0.5)',   0.0075,0.0773,10.3,  'free MC vs Chernoff bound'),
 ('T3b','SDE first exit (sigma=0.5)', 0.267, None,  None,  'absorptive MC measurement (not bounded)'),
 ('T4','SCP residual ratio',          1e-3,  1.0,   None,  'residual decay (contraction enforced)'),
 ('T5','spectral ergodic rate',       2.604, 0.762, 3.416, 'switching ensemble'),
 ('T6','OT / zone-auction gap',       0.610, 2.485, 4.07,  'Sinkhorn vs greedy (OT-auction 0.763)'),
 ('T7','burst HARQ @30%',             3.43,  2.70,  0.73,  'burst vs independent product'),
]
OT_GAP_COFLY, OT_GAP_OT, OT_CEILING_LOGM = 0.610, 0.763, 2.485
SE3_RATE_FIT, SE3_RATE_BOUND, SE3_GAIN = 8.926, 7.200, 0.8      # K = 0.8, lambda2 = 9.0
SPECTRAL_RATE_OBS, SPECTRAL_RATE_BOUND = 2.604, 0.762           # K*lambdabar2 = 0.8*0.9525
SDE_MARGINAL, SDE_BOUND, SDE_FIRSTEXIT = 0.0075, 0.0773, 0.267

# Supp. Table S13 : simulation parameters
SIMPARAMS = [
 ('scene_radius_m','R_scene',500,'geometry'),
 ('turbines/-rotor_radius_m','N_T / R_r','3 / 32','wake model'),
 ('hub_height_m','H_h',80,'geometry'),
 ('facade_height_m','H_f',36,'geometry'),
 ('mean_wind_ms','v_w',8.0,'Dryden/OU'),
 ('turbulence_intensity','I_t',0.12,'Dryden/OU'),
 ('mass_kg','m',4.2,'dynamics'),
 ('vmax_ms','v_max',15,'dynamics'),
 ('amax_ms2','a_max',8,'dynamics'),
 ('battery_Wh','E_bat',400,'energy'),
 ('fleet_size','N_U',6,'mission'),
 ('n_tasks','N_Q',30,'mission'),
 ('dmin_m','d_min',2.0,'certificates'),
 ('eps_loc_m','eps_loc',0.3,'certificates'),
 ('step_s','dt',0.1,'SCP'),
 ('horizon_s','T',5.0,'SCP'),
 ('sensing_range_m','R_s',50,'SE(3)'),
 ('consensus_gain','K',0.8,'SE(3)'),
 ('radio_ranges_km','r_l','1.5 / 2.0 / 0.5','HARQ'),
 ('ptp_target_us','eps_PTP',10,'timing'),
 ('deconflict_scale','s_sep','0.55-1.0','per-method heuristic'),
]

# solver times for methods not published in Supp. Table S14 (reconstruction, see provenance)
SOLVE_RECON = {'greedy':0.002,'centralised':0.006,'hungarian':0.004,'marl':0.010,'ot_auction':0.009}

N_RUNS = 2040
SEEDS_BASE = [42,123,256,512,1024]
SEEDS = [42,123,256,512,1024,7,13,21,34,55,89,144,233,377,610,1597,2584,4181,6765,10946]
