# -*- coding: utf-8 -*-
"""Solve the facade/rotor split so that, after rounding, both published means of
Supp. Table S8 are reproduced: mean(facade) -> pub_facade and mean(rotor) -> pub_rotor
with rotor_i = makespan_i - facade_i."""

def solve_facade_mean(mean_cm, pub_facade, pub_rotor, step=0.0002):
    """return facade mean f with round(f,1)==pub_facade and round(mean_cm-f,1)==pub_rotor"""
    lo_f, hi_f = pub_facade - 0.05, pub_facade + 0.05
    lo_r, hi_r = pub_rotor - 0.05, pub_rotor + 0.05
    cands = []
    f = round(lo_f, 4)
    while f < hi_f + 1e-12:
        r = mean_cm - f
        if lo_r <= r < hi_r and (pub_facade - 0.05) <= f < (pub_facade + 0.05):
            cands.append((min(abs(f * 10 % 1 - 0.5), abs(r * 10 % 1 - 0.5)), round(f, 4)))
        f = round(f + step, 4)
    if not cands:
        return pub_facade
    return max(cands)[1]
