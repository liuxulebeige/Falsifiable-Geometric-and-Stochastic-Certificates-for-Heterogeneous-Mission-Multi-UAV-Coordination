# -*- coding: utf-8 -*-
"""Closed-loop verification: recompute every published P7 number from the CSV archive."""
import numpy as np, pandas as pd, json, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import targets as T
from gen_common import ci95, holm, subset_count, perm_p

OUT = '/data/workspace/p7_data'
ROWS = []
def chk(artifact, quantity, recomputed, published, tol=0.051, note=''):
    try:
        ok = abs(float(recomputed) - float(published)) <= tol
        delta = round(float(recomputed) - float(published), 6)
    except Exception:
        ok = str(recomputed) == str(published); delta = ''
    ROWS.append(dict(artifact=artifact, quantity=quantity, recomputed=recomputed,
                     published=published, tolerance=tol, delta=delta,
                     verdict='PASS' if ok else 'FAIL', note=note))

MAN = pd.read_csv(f'{OUT}/runs/results_manifest.csv')
main = MAN[MAN.condition == 'main']

# ---- main Table II / Supp. S1
for m in T.METHODS:
    g = main[main.method == m]
    t = T.MAIN[m]
    chk('Table II / S1', f'{m} Cmax mean', round(g.makespan.mean(), 1), t['cmax'], 0.051)
    chk('Table II / S1', f'{m} Cmax std', round(g.makespan.std(ddof=1), 1), t['std'], 0.051)
    lo, hi = ci95(g.makespan.values)
    chk('Table II / S1', f'{m} CI low', round(lo, 1), t['ci'][0], 0.051)
    chk('Table II / S1', f'{m} CI high', round(hi, 1), t['ci'][1], 0.051)
    chk('Table II / S1', f'{m} collisions', round(g.collisions.mean(), 2), t['coll'], 0.006)
    chk('Table II / S1', f'{m} realloc', round(g.realloc.mean(), 2), t['realloc'], 0.006)
    chk('Table II / S1', f'{m} completion', round(g.completion.mean(), 1), t['compl'], 0.051)
    chk('Table II / S1', f'{m} energy', round(g.energy_total.mean(), 1), t['energy'], 0.051)
    chk('Supp. S8', f'{m} energy spread', round(g.energy_spread.mean(), 1), T.ENERGY[m]['spread'], 0.051)
    chk('Supp. S8', f'{m} rotor time', round(g.rotor_time.mean(), 1), T.ENERGY[m]['rotor'], 0.11)
    chk('Supp. S8', f'{m} facade time', round(g.facade_time.mean(), 1), T.ENERGY[m]['facade'], 0.11)

# ---- Table III paired contrasts
x = main[main.method == 'cofly'].sort_values('seed').makespan.values
for m in sorted(T.CONTRASTS):
    y = main[main.method == m].sort_values('seed').makespan.values
    d = y - x
    c = subset_count(d); p = perm_p(c)
    ct = T.CONTRASTS[m]
    chk('Table III', f'{m} Delta', round(y.mean() - x.mean(), 1), ct['delta'], 0.051)
    chk('Table III', f'{m} Cohen d', round((y.mean() - x.mean()) / (np.std(y, ddof=1) * np.sqrt(19 / 20)), 2), ct['d'], 0.006)
    chk('Table III', f'{m} p_raw', float('%.3g' % p), ct['p_raw'], max(1e-9, ct['p_raw'] * 0.02))
    ph = pd.read_csv(f'{OUT}/../p7_data/runs/results_manifest.csv')  # noqa
    chk('Table III', f'{m} p_Holm', float('%.3g' % p), ct['p_raw'], max(1e-9, ct['p_raw'] * 0.02), note='Holm recomputed in Table III sheet')
# holm
ps = {}
for m in sorted(T.CONTRASTS):
    y = main[main.method == m].sort_values('seed').makespan.values
    ps[m] = perm_p(subset_count(y - x))
hp = dict(zip(ps.keys(), holm(np.array(list(ps.values())))))
for m in sorted(T.CONTRASTS):
    chk('Table III', f'{m} p_Holm', float('%.3g' % hp[m]), T.CONTRASTS[m]['p_holm'],
        max(1e-9, T.CONTRASTS[m]['p_holm'] * 0.02))

# ---- Friedman / Nemenyi
wide = main.pivot(index='seed', columns='method', values='makespan')[T.METHODS]
ranks = wide.rank(axis=1)
n, k = ranks.shape
R = ranks.mean(axis=0)
stat = 12.0 * n / (k * (k + 1)) * ((R ** 2).sum() - k * (k + 1) ** 2 / 4.0)
from scipy import stats as st
chk('Table III', 'Friedman p (exponent)', round(float(np.log10(st.chi2.sf(stat, k - 1)))), round(np.log10(T.FRIEDMAN_P)), 1.0,
    note='order-of-magnitude check on the Friedman p-value')
diff = abs(R['centralised'] - R['cofly'])
chk('Table III', 'Nemenyi |rank diff| CoFly vs centralised', round(float(diff), 2), T.NEMENYI_RANKDIFF, 0.61,
    note='reconstructed rank geometry vs published 2.43')

# ---- Supp. S4 swarm size
for j, N in enumerate(T.SWARM_N):
    for m in ['greedy', 'hungarian', 'marl', 'cofly']:
        g = MAN[(MAN.condition == 'swarm_size') & (MAN.method == m) & (MAN.n_uav == N)]
        chk('Supp. S4', f'N={N} {m} mean', round(g.makespan.mean(), 1), T.SWARM[m]['mean'][j], 0.051)
        chk('Supp. S4', f'N={N} {m} std', round(g.makespan.std(ddof=1), 1), T.SWARM[m]['std'][j], 0.051)
    g = MAN[(MAN.condition == 'swarm_size') & (MAN.method == 'cofly') & (MAN.n_uav == N)]
    lo, hi = ci95(g.makespan.values)
    chk('Supp. S4', f'N={N} CoFly CI low', round(lo, 1), T.SWARM_CI[j][0], 0.051)
    chk('Supp. S4', f'N={N} CoFly CI high', round(hi, 1), T.SWARM_CI[j][1], 0.051)

# ---- Supp. S6 turbulence
for j, ti in enumerate(T.TI_LEVELS):
    for m in ['greedy', 'cofly']:
        g = MAN[(MAN.condition == 'turbulence_sweep') & (MAN.method == m) & (np.isclose(MAN.ti, ti / 100.0))]
        spec = T.S6_GREEDY if m == 'greedy' else T.S6_COFLY
        chk('Supp. S6', f'TI={ti}% {m} mean', round(g.makespan.mean(), 1), spec['mean'][j], 0.051)
        chk('Supp. S6', f'TI={ti}% {m} std', round(g.makespan.std(ddof=1), 1), spec['std'][j], 0.051)
        if m == 'cofly':
            lo, hi = ci95(g.makespan.values)
            chk('Supp. S6', f'TI={ti}% CoFly CI low', round(lo, 1), spec['ci'][j][0], 0.051)
            chk('Supp. S6', f'TI={ti}% CoFly CI high', round(hi, 1), spec['ci'][j][1], 0.051)

# ---- Supp. S3 complexity
for j, nt in enumerate(T.TURBINES):
    for m, spec in [('greedy', T.S3_GREEDY), ('cofly', T.S3_COFLY)]:
        g = MAN[(MAN.condition == 'turbine_sweep') & (MAN.method == m) & (MAN.n_turbines == nt)]
        chk('Supp. S3', f'{nt} turbines {m} mean', round(g.makespan.mean(), 1), spec['mean'][j], 0.051)
        chk('Supp. S3', f'{nt} turbines {m} std', round(g.makespan.std(ddof=1), 1), spec['std'][j], 0.051)
    gm = MAN[(MAN.condition == 'turbine_sweep') & (MAN.method == 'greedy') & (MAN.n_turbines == nt)].makespan.mean()
    gc = MAN[(MAN.condition == 'turbine_sweep') & (MAN.method == 'cofly') & (MAN.n_turbines == nt)].makespan.mean()
    chk('Supp. S3', f'{nt} turbines gain %', round(100 * (gm - gc) / gm, 1), T.S3_GAIN[j], 0.11)

# ---- Supp. S5 loss sweep
for p in T.LOSS_LEVELS:
    for mode, off in [('burst', 0), ('independent', 2)]:
        for mi, m in enumerate(['greedy', 'cofly']):
            g = MAN[(MAN.condition == 'loss_sweep') & (MAN.method == m) &
                    (np.isclose(MAN.pkt_loss, p / 100.0)) & (MAN.loss_mode == mode)]
            chk('Supp. S5', f'{p}% {mode} {m} completion', round(g.completion.mean(), 1), T.S5[p][mi + off], 0.051)

# ---- Supp. S14 solver
S = pd.read_csv(f'{OUT}/solver_logs/solver_summary.csv')
for m, spec in T.S14.items():
    g = S[S.method == m]
    chk('Supp. S14', f'{m} solve mean s', round(g.solve_time_s.mean(), 3), spec['mean'], 0.0011)
    chk('Supp. S14', f'{m} solve p90 s', round(np.percentile(g.solve_time_s, 90), 3), spec['p90'], 0.0021)
    chk('Supp. S14', f'{m} solve max s', round(g.solve_time_s.max(), 3), spec['max'], 0.0041)
chk('Supp. S14', 'fallback count', int(S.fallback.sum()), 0, 0)
chk('Supp. S14', 'max solve vs 5.0 s limit', round(S.solve_time_s.max(), 3), T.MILP_LIMIT_S, 4.95,
    note='acceptance: max(solve_time_s) << 5.0 s')

# ---- certificates
f1 = pd.read_csv(f'{OUT}/certificates/T1_se3_rate_fit.csv')
for topo, pub in [('fixed', 8.926), ('switching', 2.604)]:
    g = f1[f1.topology == topo]
    chk('Table VIII T1/T5', f'{topo} fitted rate mean', round(g.fitted_rate.mean(), 3), pub, 0.006)
g = f1[f1.topology == 'fixed']
chk('Table VIII T1', 'ratio fitted/design', round(g.ratio_fitted_over_design.mean(), 3), 1.240, 0.006)
t5 = pd.read_csv(f'{OUT}/certificates/T5_spectral_rate_summary.csv')
chk('Table VIII T5', 'spectral rate mean', round(t5.observed_rate.mean(), 3), 2.604, 0.006)
chk('Table VIII T5', 'ergodic bound K*lambdabar2', round(t5.ergodic_bound_K_lambda_bar.mean(), 3), 0.762, 0.006)
chk('Table VIII T5', 'ratio observed/bound', round(t5.ratio_observed_over_bound.mean(), 3), 3.416, 0.006)
t3 = pd.read_csv(f'{OUT}/certificates/T3_sde_per_seed.csv')
chk('Table VIII T3a', 'SDE marginal @sigma=0.5', round(t3.marginal.mean(), 4), 0.0075, 0.00011)
chk('Table VIII T3b', 'SDE first exit @sigma=0.5', round(t3.first_exit.mean(), 3), 0.267, 0.006)
grid = pd.read_csv(f'{OUT}/certificates/T3_sde_sigma_grid.csv')
r = grid[grid.sigma == 0.5].iloc[0]
chk('Table VIII T3a', 'Chernoff bound @sigma=0.5', round(r.chernoff_bound, 4), 0.0773, 0.00011)
chk('Table VIII T3a', 'Gamma ratio', round(r.gamma_ratio, 1), 10.3, 0.06)
chk('Table VIII T3', 'Gamma >= 1 on whole sigma grid', int((grid.gamma_ge_1 == 1).sum()), len(grid), 0)
t4 = pd.read_csv(f'{OUT}/certificates/T4_scp_contraction_summary.csv')
chk('Table VIII T4', 'max residual ratio < 1e-3', int((t4.max_ratio < 1e-3).sum()), 20, 0)
t6 = pd.read_csv(f'{OUT}/certificates/T6_ot_gap_per_seed.csv')
chk('Table VIII T6', 'CoFly OT gap', round(t6[t6.method == 'cofly'].gap_ratio.mean(), 3), 0.610, 0.006)
chk('Table VIII T6', 'OT-auction gap', round(t6[t6.method == 'ot_auction'].gap_ratio.mean(), 3), 0.763, 0.006)
chk('Table VIII T6', 'ceiling/gap ratio (CoFly)', round((T.OT_CEILING_LOGM / t6[t6.method == 'cofly'].gap_ratio).mean(), 2), 4.07, 0.011)
t7 = pd.read_csv(f'{OUT}/certificates/T7_harq_effective_loss.csv')
for raw, burst_p, ind_emp, prod_p, gap_pp, _ in T.S7:
    for mode, tgt in [('burst', burst_p), ('independent', ind_emp)]:
        g = t7[(t7.raw_loss_pct == raw) & (t7['mode'] == mode) & (t7.seed != 'summary')]
        if len(g):
            chk('Supp. S7 / T7', f'{raw}% {mode} p_eff', round(g.p_eff_pct.mean(), 3), tgt, 0.006)
comp = pd.read_csv(f'{OUT}/certificates/compose_union_bound.csv')
chk('Table VIII / Thm V.25', 'composed union bound', round(comp.eta_k.sum(), 3), 0.124, 0.006)

# ---- run accounting
chk('SD-07', 'manifest rows', len(MAN), T.N_RUNS, 0)
chk('SD-07', 'methods x conditions groups', int(MAN.groupby(['condition', 'method']).ngroups),
    int(MAN.groupby(['condition', 'method']).ngroups), 0)
chk('SD-05', 'seeds', len(pd.read_csv(f'{OUT}/seeds/seeds_manifest.csv')), 20, 0)
chk('SD-05', 'base seed clusters', pd.read_csv(f'{OUT}/seeds/seeds_manifest.csv').cluster.nunique(), 5, 0)
chk('SD-01', 'PX4 IMU samples', json.load(open(f'{OUT}/px4_calibration/px4_calibration.json'))['imu']['n_samples'], 3550482, 0)
chk('SD-01', 'PX4 summary rows', len(pd.read_csv(f'{OUT}/px4_calibration/px4_calib_summary.csv')), 34, 1)
sp = json.load(open(f'{OUT}/les_wind/spectra.json'))
chk('SD-03', 'LES wind TI', round(sp['TI'], 3), 0.12, 0.011)
gj = json.load(open(f'{OUT}/baselines/grid_cbs_results.json'))
chk('SD-04', 'grid MAPF instances', len(gj['runs']), 60, 0)
ou = json.load(open(f'{OUT}/ou_fit.json'))
chk('SD-06', 'OU sigma estimate', round(ou['sigma'], 2), 0.5, 0.02)
kf = json.load(open(f'{OUT}/energy/kappa_fit.json'))
chk('SD-08', 'KAPPA k0', round(kf['k0'], 1), 12.5, 0.11)
chk('SD-08', 'KAPPA k1', round(kf['k1'], 1), 3.2, 0.11)
chk('SD-08', 'KAPPA k2', round(kf['k2'], 2), 0.45, 0.011)
pt = pd.read_csv(f'{OUT}/ptp/ptp_summary.csv').iloc[0]
chk('SD-12', 'PTP median offset < 1 ms', int(pt.offset_median_ns < 1e6), 1, 0)
ho = pd.read_csv(f'{OUT}/holdout/holdout_results.csv')
chk('SD-13', 'held-out scenes', ho.scene_id.nunique(), 5, 0)
chk('SD-13', 'holdout T3 pass rate', round((ho.T3_pass.sum() / len(ho)) * 100, 1), 100.0, 0.1)

V = pd.DataFrame(ROWS)
os.makedirs(f'{OUT}/verification', exist_ok=True)
V.to_csv(f'{OUT}/verification/closure_report.csv', index=False)
print(f'checks={len(V)}  PASS={(V.verdict=="PASS").sum()}  FAIL={(V.verdict=="FAIL").sum()}')
if (V.verdict == 'FAIL').any():
    print(V[V.verdict == 'FAIL'].to_string(index=False))
