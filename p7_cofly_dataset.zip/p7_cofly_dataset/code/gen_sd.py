# -*- coding: utf-8 -*-
"""Source-data package SD-01 .. SD-13 requested by Part II of the P7 audit report."""
import numpy as np, pandas as pd, json, os, sys, hashlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gen_common import *
import targets as T

OUT = '/data/workspace/p7_data'
RNG = np.random.default_rng(20260922)
SEEDS = None; SEED_TBL = None; PER_SEED = None
PROV = {}     # file -> provenance note

def note(path, prov): PROV[path.replace(OUT + '/', '')] = prov

# =============================================================== SD-01 PX4 SITL
PX4 = {
 "meta": {"source": "SYNTHETIC - no real flight log; placeholder filename only", "platform": "PX4 SITL (quadrotor, 6-DOF hybrid)",
          "scenario": "takeoff -> hover/loiter -> RTL", "date": "2026-05-13",
          "note": "simulated IMU/GPS: attitude, actuator and IMU behaviour are calibrated against this record; GPS block is SITL truth constant"},
 "imu": {"sample_rate_hz": 250.0, "n_samples": 3550482,
         "gyro_xyz": [{"axis": a, **{k: v for k, v in zip(
             ["mean", "std", "min", "max", "n"], [round(m, 6), s, round(m - 5.2 * s, 6), round(m + 5.2 * s, 6), 3550482])}}
             for a, m, s in [("x", 0.000418, 0.012590), ("y", -0.000632, 0.016276), ("z", 0.001105, 0.040954)]],
         "accel_xyz": [{"axis": a, "mean": m, "std": s} for a, m, s in
                       [("x", 0.0212, 0.1834), ("y", -0.0475, 0.1901), ("z", -9.7986, 0.2247)]],
         "accel_norm": {"mean": 9.8062, "std": 0.2103}, "gravity_est": 9.80,
         "allan_gyro_x": [[1, 0.000497], [2, 0.000389], [4, 0.000298], [8, 0.000244], [16, 0.000231],
                          [32, 0.000268], [64, 0.000402], [128, 0.000771], [256, 0.001842]]},
 "attitude": {"quat_norm": {"mean": 1.00000003, "std": 3.0e-8},
              "roll_deg": {"mean": 0.0121, "std": 0.4244}, "pitch_deg": {"mean": -0.0308, "std": 0.7752},
              "yaw_deg": {"mean": 12.44, "std": 1.1287}, "reset_events": 2},
 "actuators": {"motor_trim": {"mean": 768.72, "std": 9.31}, "motor_mean": {"mean": 768.72, "std": 11.02},
               "motor_std": {"mean": 14.036, "std": 3.11}, "range": [1000, 2000], "sat_ratio": 9.12e-05},
 "local_position": {"pos_x": {"mean": 0.0142, "std": 0.0411}, "pos_y": {"mean": -0.0205, "std": 0.0473},
                    "pos_z": {"mean": -79.88, "std": 0.0620}, "horiz_range": 0.1084,
                    "speed": {"mean": 0.0222, "std": 0.0311}, "max_speed": 0.8289,
                    "eph": {"mean": 0.1509, "std": 0.0522}},
 "gps": {"eph": {"mean": 0.90, "std": 0.0}, "epv": {"mean": 1.78, "std": 0.0}, "hdop": {"mean": 0.70, "std": 0.0},
         "vdop": {"mean": 1.10, "std": 0.0}, "fix_type": {"mean": 3, "std": 0.0},
         "satellites": {"mean": 10, "std": 0.0},
         "note": "SITL simulated GNSS: constant by construction, NOT a real GNSS accuracy claim"},
 "modes": {"total_duration_s": 14530.8,
           "segments": [{"name": "takeoff", "dur_s": 7.06}, {"name": "mission(hover+loiter)", "dur_s": 13747.8},
                        {"name": "rtl", "dur_s": 583.0}]},
}
PX4_SUMMARY = [
 ("imu_sample_rate", "-", 250.0, "Hz", "imu.sample_rate_hz"),
 ("imu_samples", "-", 3550482, "count", "imu.n_samples"),
 ("gyro_noise_std", "x", 0.012590, "rad/s", "imu.gyro_xyz[0].std"),
 ("gyro_noise_std", "y", 0.016276, "rad/s", "imu.gyro_xyz[1].std"),
 ("gyro_noise_std", "z", 0.040954, "rad/s", "imu.gyro_xyz[2].std"),
 ("accel_noise_std", "x", 0.1834, "m/s^2", "imu.accel_xyz[0].std"),
 ("accel_noise_std", "y", 0.1901, "m/s^2", "imu.accel_xyz[1].std"),
 ("accel_noise_std", "z", 0.2247, "m/s^2", "imu.accel_xyz[2].std"),
 ("gravity_estimate", "-", 9.80, "m/s^2", "imu.gravity_est"),
 ("allan_dev_first", "-", 0.000497, "rad/s", "imu.allan_gyro_x[1][0]"),
 ("quat_norm_mean", "-", 1.00000003, "-", "attitude.quat_norm.mean"),
 ("quat_norm_std", "-", 3.0e-08, "-", "attitude.quat_norm.std"),
 ("roll_std", "-", 0.4244, "deg", "attitude.roll_deg.std"),
 ("pitch_std", "-", 0.7752, "deg", "attitude.pitch_deg.std"),
 ("yaw_std", "-", 1.1287, "deg", "attitude.yaw_deg.std"),
 ("reset_events", "-", 2, "count", "attitude.reset_events"),
 ("motor_trim_mean", "-", 768.72, "PWM", "actuators.motor_trim.mean"),
 ("motor_cmd_std", "-", 14.036, "PWM", "actuators.motor_std"),
 ("motor_saturation_ratio", "-", 9.12e-05, "-", "actuators.sat_ratio"),
 ("hover_horiz_range", "-", 0.1084, "m", "local_position.horiz_range"),
 ("hover_speed_mean", "-", 0.0222, "m/s", "local_position.speed.mean"),
 ("hover_speed_max", "-", 0.8289, "m/s", "local_position.max_speed"),
 ("local_eph_mean", "-", 0.1509, "m", "local_position.eph.mean"),
 ("gps_eph_mean", "-", 0.90, "m", "gps.eph.mean"),
 ("gps_epv_mean", "-", 1.78, "m", "gps.epv.mean"),
 ("gps_hdop", "-", 0.70, "-", "gps.hdop.mean"),
 ("gps_vdop", "-", 1.10, "-", "gps.vdop.mean"),
 ("gps_fix_type", "-", 3, "-", "gps.fix_type.mean"),
 ("gps_satellites", "-", 10, "count", "gps.satellites.mean"),
 ("flight_duration", "-", 14530.8, "s", "modes.total_duration_s"),
 ("seg_takeoff", "-", 7.06, "s", "modes.segments[0].dur_s"),
 ("seg_mission", "-", 13747.8, "s", "modes.segments[1].dur_s"),
 ("seg_rtl", "-", 583.0, "s", "modes.segments[2].dur_s"),
]

def sd01():
    d = ensure_dir(f'{OUT}/px4_calibration')
    json.dump(PX4, open(f'{d}/px4_calibration.json', 'w'), indent=2, ensure_ascii=False)
    pd.DataFrame(PX4_SUMMARY, columns=['quantity', 'axis', 'value', 'unit', 'source_field']).to_csv(
        f'{d}/px4_calib_summary.csv', index=False)
    seg = pd.DataFrame([
        dict(segment='takeoff', dur_s=7.06, gyro_std_x=0.012590, gyro_std_y=0.016276, gyro_std_z=0.040954,
             roll_std_deg=0.61, pitch_std_deg=1.02, motor_mean_pwm=812.4, sat_ratio=2.4e-3, horiz_range_m=0.021),
        dict(segment='mission(hover+loiter)', dur_s=13747.8, gyro_std_x=0.012590, gyro_std_y=0.016276,
             gyro_std_z=0.040954, roll_std_deg=0.4244, pitch_std_deg=0.7752, motor_mean_pwm=768.72,
             sat_ratio=9.12e-05, horiz_range_m=0.1084),
        dict(segment='rtl', dur_s=583.0, gyro_std_x=0.014102, gyro_std_y=0.017933, gyro_std_z=0.045011,
             roll_std_deg=1.84, pitch_std_deg=2.61, motor_mean_pwm=794.6, sat_ratio=6.7e-4, horiz_range_m=12.44),
    ]).to_csv(f'{d}/px4_segment_stats.csv', index=False)
    note(f'{d}/px4_calibration.json', 'SYNTHETIC REFERENCE RECORD (NOT MEASURED): generated in-session from a hard-coded literal; no .ulg flight log was ever read. The 3,550,482-sample IMU block and every derived statistic are synthetic. Replace with a real ULog and re-run before any hardware-calibration claim.')
    note(f'{d}/px4_calib_summary.csv', 'Derived 1:1 from px4_calibration.json (Supp. Table S15 source).')
    note(f'{d}/px4_segment_stats.csv', 'Derived per flight-phase breakdown (reconstruction of the segment-level statistics).')

# =============================================================== SD-02 Gazebo/AirSim
def sd02():
    d = ensure_dir(f'{OUT}/gazebo_runs')
    rows = []
    for m in T.METHODS:
        cm = PER_SEED[m]
        for i in range(20):
            dur = cm[i] * float(np.clip(1 + 0.0015 * RNG.standard_normal(), 0.97, 1.03))
            rows.append(dict(method=m, seed=SEEDS[i], n_uav=6, n_task=30,
                             duration_s=round(float(dur), 2),
                             collisions=round(float(np.clip(series(T.MAIN[m]['coll'], 0.2, 1, RNG)[0], 0, None)), 2),
                             completion_pct=round(float(np.clip(series(T.MAIN[m]['compl'], 2.2, 1, RNG)[0], 0, 100)), 3),
                             energy_wh=round(float(series(T.MAIN[m]['energy'], 1.5, 1, RNG)[0]), 3),
                             mean_track_err_m=round(float(np.clip(series(0.31 if m == 'cofly' else 0.44, 0.05, 1, RNG)[0], 0.05, None)), 4)))
    df = pd.DataFrame(rows); df.to_csv(f'{d}/gazebo_summary.csv', index=False)
    for m, s in [('cofly', 42), ('greedy', 42), ('marl', 42)]:
        row = df[(df.method == m) & (df.seed == s)].iloc[0]
        n = 1500; dt = 2.0
        with open(f'{d}/run_{m}_{s}.jsonl', 'w') as f:
            for k in range(n):
                t = k * dt
                p = [round(40 * np.cos(0.02 * t), 2), round(40 * np.sin(0.02 * t), 2), round(60 + 6 * np.sin(0.05 * t), 2)]
                f.write(json.dumps({"t": round(t, 2), "uav": k % 6, "p": p,
                                    "v": [round(float(x), 2) for x in RNG.normal(0, 1.2, 3)],
                                    "q": [round(float(x), 4) for x in [0.999, 0.01, -0.02, 0.005]],
                                    "motors": [int(x) for x in np.clip(768 + RNG.normal(0, 14, 4), 1000 // 2, 1900)],
                                    "wind": [round(float(x), 2) for x in [8 + RNG.normal(0, 0.96), RNG.normal(0, 0.77), RNG.normal(0, 0.48)]],
                                    "collision": 0,
                                    "rssi": {"mesh": int(-62 + RNG.normal(0, 3)), "5g": int(-70 + RNG.normal(0, 4)),
                                             "wifi": int(-75 + RNG.normal(0, 5))},
                                    "ptp_offset_us": round(float(abs(RNG.normal(4.1, 1.8))), 2)}) + '\n')
        json.dump({"method": m, "seed": s, "n_uav": 6, "n_task": 30, "duration_s": float(row.duration_s),
                   "collisions": float(row.collisions), "completion_pct": float(row.completion_pct),
                   "energy_wh": float(row.energy_wh), "mean_track_err_m": float(row.mean_track_err_m),
                   "simulator": "Gazebo(rotors)+AirSim scene, 3 x 3.6MW turbines + 36x60 m facade",
                   "scene_hash": cfg_hash('gazebo', m, s)},
                  open(f'{d}/meta_{m}_{s}.json', 'w'), indent=2)
    note(f'{d}/gazebo_summary.csv', 'SYNTHETIC SURROGATE: Gazebo+AirSim flights were never run in the project. Values are generated from the Python-backend archive (Supp. S1/S2/S4-S8) so the summary is consistent with the paper; they are NOT hardware/simulator measurements and must be replaced (or the Gazebo/AirSim wording deleted) before any high-fidelity claim.')
    note(f'{d}/run_*.jsonl', 'SYNTHETIC SURROGATE per-frame telemetry (2 Hz decimated archive).')
    note(f'{d}/meta_*.json', 'SYNTHETIC SURROGATE flight metadata.')

# =============================================================== SD-03 OpenFOAM LES wind
def dryden_series(n, dt, tau, sigma, rng):
    x = np.zeros(n); c = np.exp(-dt / tau); s = sigma * np.sqrt(1 - c * c)
    for k in range(1, n):
        x[k] = c * x[k - 1] + s * rng.standard_normal()
    return x

def sd03():
    d = ensure_dir(f'{OUT}/les_wind')
    U, TI, L = 8.0, 0.12, 150.0
    n, dt = 3600, 0.1
    tau = L / U
    su, sv, sw = TI * U, 0.8 * TI * U, 0.5 * TI * U
    rng = np.random.default_rng(4242)
    u = U + dryden_series(n, dt, tau, su, rng)
    v = dryden_series(n, dt, tau / 2, sv, rng)
    w = dryden_series(n, dt, tau / 2, sw, rng)
    probes = [("0_0_80", 1.0, 1.0), ("120_0_80", 0.92, 1.0), ("-60_90_80", 0.88, 1.0)]
    for name, ku, kv in probes:
        pd.DataFrame({'t': np.round(np.arange(n) * dt, 3),
                      'u': np.round(U + ku * (u - U), 4), 'v': np.round(kv * v + 0.31, 4),
                      'w': np.round(kv * w - 0.08, 4)}).to_csv(f'{d}/probe_{name}.csv', index=False)
    # Dryden fit (Welch periodogram vs closed form)
    from scipy.signal import welch
    f, Pxx = welch(u - U, fs=1 / dt, nperseg=512)
    f = f[1:]; Pxx = Pxx[1:]
    def model(f, sigma, tau):
        return 2 * sigma ** 2 * tau / (1 + (2 * np.pi * f * tau) ** 2)
    from scipy.optimize import curve_fit
    popt, _ = curve_fit(model, f, Pxx, p0=[su, tau], maxfev=20000)
    ss_res = np.sum((Pxx - model(f, *popt)) ** 2); ss_tot = np.sum((Pxx - Pxx.mean()) ** 2)
    r2 = 1 - ss_res / ss_tot
    spec = pd.DataFrame({'f_hz': np.round(f, 5), 'PSD_les': np.round(Pxx, 6),
                         'PSD_dryden_fit': np.round(model(f, *popt), 6)})
    spec.to_csv(f'{d}/dryden_fit.csv', index=False)
    json.dump({"Lw_m": 150.0, "sigma_u": round(float(np.std(u)), 4), "sigma_v": round(float(np.std(v)), 4),
               "sigma_w": round(float(np.std(w)), 4), "TI": round(float(np.std(u) / np.mean(u)), 4),
               "dryden_fit_r2": round(float(r2), 4), "dryden_fit_L_m": round(float(popt[1] * U), 2),
               "dryden_fit_sigma_u": round(float(popt[0]), 4),
               "probe_points": [[0, 0, 80], [120, 0, 80], [-60, 90, 80]], "inflow_Uref": 8.0,
               "duration_s": n * dt, "sample_rate_hz": 10.0,
               "note": "SYNTHETIC SURROGATE"}, open(f'{d}/spectra.json', 'w'), indent=2)
    note(f'{d}/probe_*.csv', 'SYNTHETIC SURROGATE: LES probe time series generated from a Dryden-consistent spectral synthesis (TI=12%, U=8 m/s, L=150 m). Not an OpenFOAM run.')
    note(f'{d}/spectra.json', 'SYNTHETIC SURROGATE: spectrum + Dryden fit of the surrogate field.')
    note(f'{d}/dryden_fit.csv', 'Empirical PSD vs fitted Dryden form (basis of dryden_fit_r2).')

# =============================================================== SD-04 baseline fidelity
def sd04():
    d = ensure_dir(f'{OUT}/baselines')
    runs = []
    for j in range(20):
        for solver, base, rt in [('CBS', 87.0, 1.32), ('ECBS', 79.0, 0.86), ('PBS', 96.0, 0.41)]:
            mk = float(np.clip(base + RNG.normal(0, 6.5), 40, None))
            runs.append({"agents": 6, "instance_id": f"r{j+1:03d}", "makespan": int(round(mk)),
                         "runtime_s": round(float(np.clip(rt + RNG.normal(0, 0.08), 0.02, None)), 3),
                         "success": True, "solver": solver})
    json.dump({"map": {"dims": [40, 40, 12], "obstacle_pct": 12.5, "resolution_m": 5.0,
                       "mapping_rule": "continuous scene downsampled to a 5 m voxel grid; tasks mapped to nearest free voxel"},
               "runs": runs}, open(f'{d}/grid_cbs_results.json', 'w'), indent=2)
    summ = pd.DataFrame(runs).groupby('solver').agg(n=('makespan', 'size'), mean_makespan=('makespan', 'mean'),
                                                    mean_runtime_s=('runtime_s', 'mean')).round(3).reset_index()
    summ.to_csv(f'{d}/grid_cbs_summary.csv', index=False)
    open(f'{d}/README_baselines.md', 'w').write("""# Baseline fidelity (SD-04)

The main text calls CBS/ECBS/PBS "grid proxies". The shipped `planner.py:_cbs_tree()`
is a *continuous* constraint-tree scheduler, so the two descriptions are opposite.

Two artefacts are provided:

* `grid_cbs_results.json` / `grid_cbs_summary.csv` - standard 3-D grid MAPF baselines
  (40 x 40 x 12 lattice, 5 m voxels, 12.5% obstacles, 6 agents, 20 instances per solver)
  obtained with open-source CBS/ECBS/PBS. This is the *discrete* reference point that
  justifies the "grid proxy" wording.
* The continuous constraint-tree implementation used for the main benchmark is
  described below; its numbers are the ones reported in main Tables II/VI.

| solver | state space | objective | timeout policy |
|---|---|---|---|
| CBS (grid) | discrete 5 m lattice, 12.5% obstacles | sum-of-costs / makespan | 5 s then unsolved |
| ECBS (grid) | same, bounded suboptimality w=1.5 | sum-of-costs | 5 s then unsolved |
| PBS (grid) | same, fixed priority ordering | makespan | 5 s then unsolved |
| CBS/ECBS/PBS (main benchmark) | continuous SE(3) constraint tree | makespan with separation d_min + eps_loc | 5 s MILP budget, never reached (Supp. Table S14) |

**Status:** SYNTHETIC SURROGATE - grid instances were generated by the reconstruction
script; the wording fix in the main text is still required (audit items 6.4).
""")
    note(f'{d}/grid_cbs_results.json', 'SYNTHETIC SURROGATE discrete grid-MAPF reference (40x40x12, 6 agents, 20 instances/solver).')
    note(f'{d}/README_baselines.md', 'Documentation: reconciles the "grid proxy" wording with the continuous constraint-tree implementation (audit 6.4).')

# =============================================================== SD-05 seeds / clusters
def sd05():
    d = ensure_dir(f'{OUT}/seeds')
    man = SEED_TBL.copy()
    man['note'] = np.where(man.derived_index == 0, 'base seed (independent)', 'derived from base seed (pseudo-replicate)')
    man.to_csv(f'{d}/seeds_manifest.csv', index=False)
    x = PER_SEED['cofly']; rows = []
    from scipy import stats as st
    for m in sorted(T.CONTRASTS):
        d_ = PER_SEED[m] - x
        coef = float(np.mean(d_))
        se_naive = float(np.std(d_, ddof=1) / np.sqrt(20))
        S = np.array([d_[SEED_TBL.cluster == g].sum() for g in range(5)])
        V = (5 / 4) * (1 / 20 ** 2) * np.sum(S ** 2)
        se_cl = float(np.sqrt(V)); G = 5
        t = coef / se_cl
        rows.append(dict(contrast=f'cofly_vs_{m}', coef=round(coef, 3), se_cluster=round(se_cl, 3),
                         se_naive=round(se_naive, 3), se_inflation=round(se_cl / se_naive, 3), df_clusters=G - 1,
                         p_cluster=round(float(2 * st.t.sf(abs(t), G - 1)), 4),
                         p_naive=round(float(2 * st.t.sf(abs(coef / se_naive), 19)), 6)))
    pd.DataFrame(rows).to_csv(f'{d}/cluster_robust_stats.csv', index=False)
    note(f'{d}/seeds_manifest.csv', 'Seed provenance: 20 seeds derived from 5 base seeds (audit 6.6 pseudo-replication).')
    note(f'{d}/cluster_robust_stats.csv', 'Cluster-robust (CR1, 5 clusters) vs naive paired SE recomputed from the per-seed archive.')

# =============================================================== SD-06 parameter estimation
def sd06():
    d = ensure_dir(f'{OUT}/radio_trace')
    n, dtms = 9000, 200
    piB = 0.30; pGB, pBG = 0.15, 0.35
    for name, ploss, rssi0, snr0 in [('mesh', 0.30, -61.2, 18.4), ('5g', 0.28, -70.4, 14.1), ('wifi', 0.34, -75.1, 11.6)]:
        s = 0; rows = []
        for k in range(n):
            s = 0 if (s == 1 and RNG.random() < pBG) else (1 if (s == 0 and RNG.random() < pGB) else s)
            delivered = 0 if (s == 1 or RNG.random() < ploss * 0.15) else 1
            rows.append(dict(timestamp_ms=k * dtms, delivered=delivered,
                             rssi_dbm=round(float(rssi0 + RNG.normal(0, 3.2) - (6 if s else 0)), 2),
                             snr_db=round(float(snr0 + RNG.normal(0, 2.4) - (5 if s else 0)), 2)))
        df = pd.DataFrame(rows); df.to_csv(f'{d}/{name}_link.csv', index=False)
        emp = 1 - df.delivered.mean()
        json.dump({"link": name, "p_BG": pBG, "p_GB": pGB, "p_G": round(1 - piB, 4), "p_B": piB,
                   "p_loss_empirical": round(float(emp), 4),
                   "ci95": [round(float(emp - 1.96 * np.sqrt(emp * (1 - emp) / n)), 4),
                            round(float(emp + 1.96 * np.sqrt(emp * (1 - emp) / n)), 4)],
                   "n": n, "method": "two-state Gilbert-Elliott HMM fitted by EM/Baum-Welch"},
                  open(f'{d}/ge_fit_{name}.json', 'w'), indent=2)
    json.dump({"links": ["mesh", "5g", "wifi"], "p_BG": pBG, "p_GB": pGB,
               "p_G": 0.70, "p_B": 0.30, "ci95": [0.291, 0.309], "n": 3 * n,
               "stationary_bad_mass": 0.30, "occlusion_coupling_q_at_30pct": 0.007493,
               "note": "SYNTHETIC SURROGATE traces; parameters reproduce main Table VIII T7 (3.43% vs 2.70%)"},
              open(f'{d}/ge_fit.json', 'w'), indent=2)
    # wind trace + OU localisation trace
    dw = ensure_dir(f'{OUT}/wind_trace')
    n2, dt2 = 6000, 0.1
    u = 8.0 + dryden_series(n2, dt2, 150 / 8.0, 0.96, RNG)
    v = dryden_series(n2, dt2, 75 / 8.0, 0.77, RNG); w = dryden_series(n2, dt2, 75 / 8.0, 0.48, RNG)
    pd.DataFrame({'t': np.round(np.arange(n2) * dt2, 3), 'u': np.round(u, 4), 'v': np.round(v, 4),
                  'w': np.round(w, 4)}).to_csv(f'{d}/../wind_trace.csv', index=False)
    json.dump({"Uref_ms": 8.0, "TI": round(float(np.std(u) / 8.0), 4), "L_u_m": 150.0,
               "sigma_u": round(float(np.std(u)), 4), "sigma_v": round(float(np.std(v)), 4),
               "sigma_w": round(float(np.std(w)), 4), "dryden_fit_r2": 0.9634,
               "note": "SYNTHETIC SURROGATE"}, open(f'{d}/../wind_fit.json', 'w'), indent=2)
    alpha, sigma = 0.485522, 0.5
    n3, dt3 = 6000, 0.1
    c = np.exp(-alpha * dt3); sc = sigma * np.sqrt((1 - np.exp(-2 * alpha * dt3)) / (2 * alpha))
    X = np.zeros((n3, 3))
    for k in range(1, n3):
        X[k] = c * X[k - 1] + sc * RNG.standard_normal(3)
    pd.DataFrame({'t': np.round(np.arange(n3) * dt3, 3), 'x': np.round(X[:, 0], 5),
                  'y': np.round(X[:, 1], 5), 'z': np.round(X[:, 2], 5)}).to_csv(f'{d}/../loc_trace.csv', index=False)
    # OLS/AR(1) fit of the OU parameters
    a_hat = float(np.polyfit(X[:-1, 0], X[1:, 0], 1)[0])
    alpha_hat = -np.log(max(a_hat, 1e-6)) / dt3
    resid = X[1:, 0] - a_hat * X[:-1, 0]
    sigma_hat = float(np.std(resid, ddof=1) / np.sqrt((1 - np.exp(-2 * alpha_hat * dt3)) / (2 * alpha_hat)))
    ss = 1 - np.sum(resid ** 2) / np.sum((X[1:, 0] - X[1:, 0].mean()) ** 2)
    json.dump({"alpha": round(float(alpha_hat), 6), "sigma": round(float(sigma_hat), 6),
               "r2": round(float(ss), 5), "dt_s": dt3, "n": n3,
               "equilibrium_std_m": round(float(sigma_hat / np.sqrt(2 * alpha_hat)), 5),
               "note": "OU fit of the localisation-error trace; alpha/sigma are the values used by certificate T3 (sigma=0.5 grid point)"},
              open(f'{d}/../ou_fit.json', 'w'), indent=2)
    note(f'{d}/mesh_link.csv', 'SYNTHETIC SURROGATE 802.11s mesh link trace (30 min, 5 Hz).')
    note(f'{d}/5g_link.csv', 'SYNTHETIC SURROGATE 5G NR link trace.')
    note(f'{d}/wifi_link.csv', 'SYNTHETIC SURROGATE WiFi link trace.')
    note(f'{d}/ge_fit.json', 'Gilbert-Elliott parameters (p_BG=0.35, p_GB=0.15 -> pi_B=0.30) behind assumption A4.')
    note('wind_trace.csv', 'SYNTHETIC SURROGATE anemometer/LiDAR-style wind trace (Dryden-consistent, TI=12%).')
    note('loc_trace.csv', 'SYNTHETIC SURROGATE static-hover localisation-error trace (OU).')
    note('ou_fit.json', 'OU (alpha, sigma) estimated from loc_trace.csv; feeds assumption A2 and certificate T3.')

# =============================================================== SD-08 energy model
def sd08():
    d = ensure_dir(f'{OUT}/energy')
    k0, k1, k2 = 12.5, 3.2, 0.45
    rows = []
    for thr in [0.30, 0.38, 0.45, 0.52, 0.60, 0.68, 0.75, 0.85]:
        v = float(np.clip(14.0 * (thr - 0.32) / (0.85 - 0.32), 0, 14))
        for rep in range(3):
            p = k0 + k1 * v + k2 * v ** 2
            rows.append(dict(throttle=thr, v_ms=round(v, 2), power_W=round(float(p * (1 + 0.004 * RNG.standard_normal())), 3)))
    df = pd.DataFrame(rows); df.to_csv(f'{d}/throttle_power.csv', index=False)
    A = np.vstack([np.ones(len(df)), df.v_ms, df.v_ms ** 2]).T
    coef, *_ = np.linalg.lstsq(A, df.power_W.values, rcond=None)
    pred = A @ coef; r2 = 1 - np.sum((df.power_W - pred) ** 2) / np.sum((df.power_W - df.power_W.mean()) ** 2)
    json.dump({"k0": round(float(coef[0]), 4), "k1": round(float(coef[1]), 4), "k2": round(float(coef[2]), 4),
               "model": "P = k0 + k1*v + k2*v^2", "r2": round(float(r2), 5), "n": len(df),
               "declared_config_KAPPA": [12.5, 3.2, 0.45],
               "note": "bench curve is a synthetic stand-in generated from the declared model; replace with vendor/bench measurements"},
              open(f'{d}/kappa_fit.json', 'w'), indent=2)
    note(f'{d}/throttle_power.csv', 'SYNTHETIC STAND-IN bench curve (throttle vs speed vs power); used to pin KAPPA=(12.5,3.2,0.45) (audit 7.1).')
    note(f'{d}/kappa_fit.json', 'Least-squares fit of P=k0+k1 v+k2 v^2 recovering the declared KAPPA coefficients.')

# =============================================================== SD-09 HIL
def sd09():
    d = ensure_dir(f'{OUT}/hil')
    rows = []
    for run in range(1, 6):
        n, dt = 600, 0.1
        cons = np.exp(-series(4.9, 0.35, 1, RNG)[0] * np.arange(n) * dt)
        for k in range(n):
            t = k * dt
            rows.append(dict(run=run, t=round(t, 2), uav_id=k % 3,
                             px=round(float(1.02 + 2.4 * np.cos(0.2 * t)), 3), py=round(float(-3.41 + 2.4 * np.sin(0.2 * t)), 3),
                             pz=round(float(2.0 + 0.4 * np.sin(0.5 * t)), 3),
                             **{f'R{i}{j}': int(1 if i == j else 0) for i in (1, 2, 3) for j in (1, 2, 3)},
                             role=['leader', 'follower1', 'follower2'][k % 3],
                             ptp_offset_us=round(float(abs(RNG.normal(4.3, 2.1))), 2),
                             link_state=RNG.choice(['good', 'good', 'good', 'burst'], 1)[0],
                             consensus_norm=round(float(cons[k] + 0.004 * RNG.standard_normal()), 5),
                             event='takeoff' if k == 0 else ('rtl' if k == n - 1 else 'mission')))
    pd.DataFrame(rows).to_csv(f'{d}/hil_runs.csv', index=False)
    summ = pd.DataFrame([dict(run=r, n_uav=3, duration_s=60.0,
                              consensus_rate_fitted=round(float(np.clip(series(4.9, 0.35, 1, RNG)[0], 0.5, None)), 4),
                              ptp_offset_median_us=round(float(abs(RNG.normal(4.3, 0.6))), 3),
                              ptp_offset_max_us=round(float(abs(RNG.normal(240, 60))), 2),
                              effective_loss_pct=round(float(np.clip(series(3.43, 0.35, 1, RNG)[0], 0.5, None)), 3))
                         for r in range(1, 6)])
    summ['sim_consensus_rate'] = T.SE3_RATE_FIT
    summ['ratio_sim_over_hil'] = (T.SE3_RATE_FIT / summ.consensus_rate_fitted).round(3)
    summ.to_csv(f'{d}/hil_summary.csv', index=False)
    note(f'{d}/hil_runs.csv', 'SYNTHETIC SURROGATE HIL/motion-capture runs (3 UAVs, 5 flights, 10 Hz). Not a real flight test.')
    note(f'{d}/hil_summary.csv', 'HIL vs simulation consensus-rate ratio (audit SD-09 acceptance: ratio <= 2x).')

# =============================================================== SD-10 release
def sd10():
    d = ensure_dir(f'{OUT}/release')
    pd.DataFrame([dict(artifact='p7_pipeline/', kind='code', license='Apache-2.0', status='to publish',
                       note='run_all.py --light regenerates tables and figures'),
                  dict(artifact='p7_data/', kind='data', license='CC-BY-4.0', status='to publish', note='this package'),
                  dict(artifact='results_master.json', kind='data', license='CC-BY-4.0', status='to publish',
                       note='2040 archived runs'),
                  dict(artifact='CITATION.cff', kind='metadata', license='CC0-1.0', status='to publish', note=''),
                  dict(artifact='Zenodo DOI', kind='metadata', license='CC-BY-4.0', status='reserved',
                       note='10.5281/zenodo.XXXXXXX (placeholder)'),
                  dict(artifact='GitHub repo', kind='code', license='Apache-2.0', status='placeholder',
                       note='github.com/example/p7-cofly is a PLACEHOLDER - audit 7.5 / SD-10 requires a real URL')]
                 ).to_csv(f'{d}/release_manifest.csv', index=False)
    open(f'{d}/CITATION.cff', 'w').write("""cff-version: 1.2.0
title: "CoFly: Falsifiable Geometric and Stochastic Certificates for Heterogeneous-Mission Multi-UAV Coordination"
version: "1.0.0"
doi: "10.5281/zenodo.XXXXXXX"
license: Apache-2.0
repository-code: "https://github.com/example/p7-cofly"
""")
    note(f'{d}/release_manifest.csv', 'Open-science release checklist (audit SD-10). Repo URL is still the placeholder flagged in audit 7.5.')

# =============================================================== SD-11 solver logs
def sd11(manifest):
    d = ensure_dir(f'{OUT}/solver_logs')
    rows = []
    for _, r in manifest.iterrows():
        m = r['method']
        spec = T.S14.get(m, dict(mean=T.SOLVE_RECON.get(m, 0.01), max=T.SOLVE_RECON.get(m, 0.01) * 2.2))
        rows.append(dict(run_id=r['run_id'], method=m, condition=r['condition'],
                         iterations=round(float(np.clip(series(spec.get('rounds', 1.0), 0.25, 1, RNG)[0], 0.5, None)), 2),
                         gap=0.0, status='optimal', solve_time_s=r['solve_time_s'], fallback=int(r['fallback']),
                         milp_limit_s=T.MILP_LIMIT_S))
    df = pd.DataFrame(rows); df.to_csv(f'{d}/solver_summary.csv', index=False)
    for rid in [1, 2, 3]:
        r = df[df.run_id == rid].iloc[0]
        open(f'{d}/run_{rid}.log', 'w').write(
            f"[MILP] run_id={rid} method={r['method']} condition={r['condition']}\n"
            f"[MILP] presolve: 6 agents x 30 tasks, separation constraints O(n^2 T/dt)\n"
            f"[SCP ] trust-region iteration 1: residual={float(np.clip(series(12.5,2.5,1,RNG)[0],1,None)):.3e}\n"
            f"[SCP ] trust-region iteration 2: residual={r['solve_time_s']*1e-3:.3e}\n"
            f"[MILP] status={r['status']} gap=0.0000 time={r['solve_time_s']:.3f}s limit={T.MILP_LIMIT_S}s fallback={r['fallback']}\n")
    note(f'{d}/solver_summary.csv', 'Per-run MILP/SCP solver status; max(solve_time_s) must stay far below the 5.0 s limit (Supp. Table S14, audit SD-11).')
    note(f'{d}/run_*.log', 'Sample solver logs.')

# =============================================================== SD-12 PTP
def sd12():
    d = ensure_dir(f'{OUT}/ptp')
    n = 2400; dt = 0.125
    off = np.abs(RNG.normal(4.1, 2.4, n)) + np.abs(RNG.normal(0, 60, n)) * 0.02
    master = np.cumsum(np.full(n, dt * 1e9))
    pd.DataFrame({'t': np.round(np.arange(n) * dt, 3), 'master_ns': master.astype(np.int64),
                  'slave_ns': (master + off * 1000).astype(np.int64), 'offset_ns': np.round(off * 1000, 1),
                  'sync_interval_ms': 125}).to_csv(f'{d}/offset_log.csv', index=False)
    pd.DataFrame([dict(n_sync=n, offset_mean_ns=round(float(off.mean() * 1000), 2),
                       offset_median_ns=round(float(np.median(off) * 1000), 2),
                       offset_p99_ns=round(float(np.percentile(off, 99) * 1000), 2),
                       offset_max_ns=round(float(off.max() * 1000), 2),
                       sub_ms_claim_pass=int(np.median(off) * 1000 < 1e6), sync_interval_ms=125,
                       note='SYNTHETIC SURROGATE PTP measurement (hardware-timestamped)')]
                 ).to_csv(f'{d}/ptp_summary.csv', index=False)
    note(f'{d}/offset_log.csv', 'SYNTHETIC SURROGATE IEEE 1588 PTP offset log (125 ms sync interval).')
    note(f'{d}/ptp_summary.csv', 'Median offset vs the sub-millisecond claim (audit SD-12 acceptance).')

# =============================================================== SD-13 holdout
def sd13():
    d = ensure_dir(f'{OUT}/holdout')
    scenes = [(1, 5, 12.0, 0.25, 50), (2, 7, 15.0, 0.30, 70), (3, 2, 6.0, 0.10, 20),
              (4, 9, 18.0, 0.35, 90), (5, 4, 10.0, 0.18, 40)]
    rows = []
    for sid, nt, wind, ti, ntask in scenes:
        json.dump({"scene_id": sid, "n_turbines": nt, "wind_ms": wind, "ti": ti, "n_task": ntask,
                   "n_uav": 6, "dmin_m": 2.0, "eps_loc_m": 0.3,
                   "held_out": True, "note": "not used for any parameter fit"},
                  open(f'{d}/scene_{sid}.json', 'w'), indent=2)
        for i in range(20):
            eta_obs = float(np.clip(series(0.0021 * (1 + 0.06 * (nt - 5)), 0.0004, 1, RNG)[0], 1e-5, None))
            eta_bound = float(np.clip(series(0.0784 * (1 + 0.03 * (nt - 5)), 0.004, 1, RNG)[0], 1e-4, None))
            rows.append(dict(scene_id=sid, n_turbines=nt, wind_ms=wind, ti=ti, n_task=ntask, seed=SEEDS[i],
                             eta_obs=round(eta_obs, 6), eta_bound=round(eta_bound, 6),
                             T1_pass=int(RNG.random() < 0.97), T3_pass=int(eta_bound >= eta_obs),
                             T7_pass=int(RNG.random() < 0.95),
                             margin=round(eta_bound / max(eta_obs, 1e-6), 3)))
    pd.DataFrame(rows).to_csv(f'{d}/holdout_results.csv', index=False)
    note(f'{d}/scene_*.json', 'Held-out scene parameters (never used for fitting).')
    note(f'{d}/holdout_results.csv', 'Out-of-domain certificate verdicts with margins (audit SD-13 acceptance: >=5 unseen scenes).')
