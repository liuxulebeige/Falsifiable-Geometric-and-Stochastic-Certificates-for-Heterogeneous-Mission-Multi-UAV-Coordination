# Reference dataset for the P7 multi-UAV certificate paper

118 files. Deposit date 2026-09-21.

## Start here

1. `PROVENANCE.md` - **mandatory reading**. States exactly which files are measured,
   reconstructed, or synthetic, and which may be cited as evidence.
2. `provenance.csv` - same information, machine readable, one row per file.
3. `inventory.csv` - file inventory with row/column counts.
4. `verification/closure_report.csv` - 322 closed-loop checks, all PASS.

## One-line summary of what this is

A **reference / reproducibility dataset**: its per-seed values were solved so that their
sample statistics reproduce the published tables exactly, and its remaining blocks are
documented synthetic placeholders for experiments that were not run. It lets a reader
re-run the pipeline and verify internal consistency. It does **not** contain new
measurements and cannot corroborate the paper's empirical claims.

## Suggested Data Availability wording (honest form)

> The aggregates reported in this paper are reproducible from the reference dataset
> deposited at [DOI] ([repository URL]). The deposit contains reconstructed per-seed
> values whose sample statistics match the published tables, plus documented synthetic
> placeholders for the simulator/HIL/wind/radio/PTP blocks that were not executed;
> `PROVENANCE.md` in the deposit specifies, file by file, which content is measured,
> reconstructed, or synthetic. No value in the deposit originates from a physical
> flight test.

Do **not** write "source data" or "raw measurements" - the deposit's own provenance file
contradicts that, and reviewers will check.

## Reproducing

```
cd code && python3 gen_all.py && python3 gen_tables.py && python3 verify.py
```

## Before you deposit

Replace every `<...>` placeholder and the prereserved DOI in `CITATION.cff` and
`.zenodo.json` with real values (author name, ORCID, repository URL, Zenodo DOI).
